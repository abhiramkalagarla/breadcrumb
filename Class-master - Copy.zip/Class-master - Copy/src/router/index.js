import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

const router = new Router({
  mode: 'hash',
  routes: [
    // Each of these routes are loaded asynchronously, when a user first navigates to each corresponding endpoint.
    // The route will load once into memory, the first time it's called, and no more on future calls.
    // This behavior can be observed on the network tab of your browser dev tools.
    {
      path: '/login',
      name: 'login',
      component: (resolve) => {
        require(['@/components/login/Login.vue'], resolve)
      }
    },
    {
      path: '/',
      redirect: 'home'
    },
    {
      path: '/home',
      name: 'home',
      component: (resolve) => {
        require(['@/components/dashboard/Dashboard.vue'], resolve)
      },
      meta: {
        breadcrumb: 'Home'
    },
    beforeEnter: guardRoute
    },
    {
      path: '/serverInfo',
      name: 'ServerInfo',
      component: (resolve) => {
        require(['@/components/serverInfo/ServerInfo.vue'], resolve)
      },
      meta: {
       breadcrumb: 'Server Info'
    },
    beforeEnter: guardRoute
    },
    {
      path: '/applicationInfo',
      name: 'applicationInfo',
      meta: {
        breadcrumb: 'Application Info'
    },
      component: (resolve) => {
        require(['@/components/applicationInfo/ApplicationInfo.vue'], resolve)
      },
   beforeEnter: guardRoute
    },
    {
      path: '/placeorder',
      name: 'placeorder',
      meta: {
        breadcrumb: 'Place Order'
    },
      component: (resolve) => {
        require(['@/components/placeOrder/PlaceOrder.vue'], resolve)
      },
    beforeEnter: guardRoute
    },
    {
      path: '/orderhistory',
      name: 'orderhistory',
      meta: {
        breadcrumb: 'Order History'
    },
      component: (resolve) => {
        require(['@/components/orderHistory/OrderHistory.vue'], resolve)
      },
   beforeEnter: guardRoute
    },
    {
      path: '/scaleIO',
      name: 'scaleIO',
      meta: {
        breadcrumb: 'Scale IO'
    },
      component: (resolve) => {
        require(['@/components/scaleIO/ScaleIO.vue'], resolve)
      }
    // beforeEnter: guardRoute
    },
    {
      path: '/scaleIO/Cluster',
      name: 'Cluster',
      meta: {
        breadcrumb: 'Cluster'
    },
      component: (resolve) => {
        require(['@/components/scaleIO/Cluster/cluster/Cluster.vue'], resolve)
      },
 beforeEnter: guardRoute
    },
    {
      path: '/scaleIO/Cluster/:clustername',
      name: 'indCluster',
      meta: {
        breadcrumb: 'Cluster'
    },
      component: (resolve) => {
        require(['@/components/scaleIO/Cluster/indCluster/indCluster.vue'], resolve)
      },
   beforeEnter: guardRoute
    },
    {
      path: '/scaleIO/Pools',
      name: 'Pools',
      meta: {
        breadcrumb: 'Pools'
    },
      component: (resolve) => {
        require(['@/components/scaleIO/Pools/pools/Pools.vue'], resolve)
      },
  beforeEnter: guardRoute
    },
    {
      path: '/scaleIO/Pools/:citipoolname',
      name: 'Citipool',
      meta: {
        breadcrumb: 'CitiPools'
    },
      component: (resolve) => {
        require(['@/components/scaleIO/Pools/indPool/indPool.vue'], resolve)
      },
  beforeEnter: guardRoute
    },
    {
      path: '/scaleIO/VirtualPool',
      name: 'VirtualPool',
      meta: {
        breadcrumb: 'VirtualPool'
    },
      component: (resolve) => {
        require(['@/components/scaleIO/Virtual Pool/virtualPool/VirtualPool.vue'], resolve)
      },
  beforeEnter: guardRoute
    },
    {
      path: '/scaleIO/VirtualPool/:vpID/:vpName',
      name: 'IndvirtualPool',
      meta: {
        breadcrumb: 'VirtualPool'
    },
      component: (resolve) => {
        require(['@/components/scaleIO/Virtual Pool/indVirtualPool/indVirtualPool.vue'], resolve)
      },
   beforeEnter: guardRoute
    },
    {
      path: '/scaleIO/Subscribers',
      name: 'Subscribers',
      meta: {
        breadcrumb: 'Subscribers'
    },
      component: (resolve) => {
        require(['@/components/scaleIO/Subscribers/subscribers/subscribers.vue'], resolve)
      },
  beforeEnter: guardRoute
    },
    {
      path: '/scaleIO/Subscribers/:subscriberid',
      name: 'indSubscriber',
      meta: {
        breadcrumb: 'Subscribers'
    },
      component: (resolve) => {
        require(['@/components/scaleIO/Subscribers/indSubscriber/indSubscriber.vue'], resolve)
      },
  beforeEnter: guardRoute
    },
    {
      path: '/scaleIO/SDCs',
      name: 'SDCs',
      meta: {
        breadcrumb: 'SDCs'
    },
      component: (resolve) => {
        require(['@/components/scaleIO/SDCs/sdcs.vue'], resolve)
      },
  beforeEnter: guardRoute
    },
    {
      path: '/scaleIO/VMSubscribers',
      name: 'VMSubscribers',
      meta: {
        breadcrumb: 'VM Subscribers'
    },
      component: (resolve) => {
        require(['@/components/scaleIO/VMSubscribers/VMSubscribers.vue'], resolve)
      }
 // beforeEnter: guardRoute
    },
    {
      path: '/scaleIO/HostProvisioning',
      name: 'HostProvisioning',
      meta: {
        breadcrumb: 'Host Provisioning'
    },
      component: (resolve) => {
        require(['@/components/scaleIO/HostProvisioning/hostProvisioning.vue'], resolve)
      },
     beforeEnter: guardRoute
    },
    {
      path: '/vmReplication',
      name: 'vmReplication',
      meta: {
        breadcrumb: 'VM Replication'
    },
      component: (resolve) => {
        require(['@/components/vmReplication/VMReplication.vue'], resolve)
      },
  beforeEnter: guardRoute
    },
    {
      path: '/actifio',
      name: 'actifio',
      meta: {
        breadcrumb: 'actifio'
    },
      component: (resolve) => {
        require(['@/components/actifio/actifioCard.vue'], resolve)
      }
     // beforeEnter: guardRoute
    },
    {
      path: '/actifio/manageDatabaseBackup',
      name: 'manageDatabaseBackup',
      meta: {
        breadcrumb: 'Manage Database Backup'
    },
      component: (resolve) => {
        require(['@/components/actifio/manageDatabaseBackup/dashboard/dashboard.vue'], resolve)
      }
   // beforeEnter: guardRoute
    },
    {
      path: '/actifio/manageDatabaseBackup/recovery',
      name: 'manageDatabaserecovery',
      meta: {
        breadcrumb: 'Manage Database Backup'
    },
      component: (resolve) => {
        require(['@/components/actifio/manageDatabaseBackup/recovery/recovery.vue'], resolve)
      }
   // beforeEnter: guardRoute
    },
    {
      path: '/actifio/manageDatabaseBackup/checkCurrentMounts',
      name: 'manageDatabasecheckMounts',
      meta: {
        breadcrumb: 'Manage Database Backup'
    },
      component: (resolve) => {
        require(['@/components/actifio/manageDatabaseBackup/checkCurrentMounts/checkCurrentMounts.vue'], resolve)
      }
   // beforeEnter: guardRoute
    },
    {
      path: '/actifio/manageDatabaseBackup/manageAdvancedSettings',
      name: 'manageDatabaseSettings',
      meta: {
        breadcrumb: 'Manage Database Backup'
    },
      component: (resolve) => {
        require(['@/components/actifio/manageDatabaseBackup/manageAdvancedSettings/manageAdvancedSettings.vue'], resolve)
      }
   // beforeEnter: guardRoute
    },
    {
      path: '/actifio/manageDatabaseBackup/toggleBackup',
      name: 'manageDatabaseToggle',
      meta: {
        breadcrumb: 'Manage Database Backup'
    },
      component: (resolve) => {
        require(['@/components/actifio/manageDatabaseBackup/toggleBackup/toggleBackup.vue'], resolve)
      }
  //  beforeEnter: guardRoute
    },
    {
      path: '/actifio/manageDatabaseBackup/removeBackupProtection',
      name: 'manageDatabaseBackupProtection',
      meta: {
        breadcrumb: 'Manage Database Backup'
    },
      component: (resolve) => {
        require(['@/components/actifio/manageDatabaseBackup/removeBackupProtection/removeBackupProtection.vue'], resolve)
      },
   beforeEnter: guardRoute
    },
    {
      path: '/actifio/databaseBackupDashboard',
      name: 'databaseBackupDashboard',
      meta: {
        breadcrumb: 'Database Backup Dashboard'
    },
      component: (resolve) => {
        require(['@/components/actifio/databaseBackupDashboard/databaseBackupDashboard.vue'], resolve)
      },
    beforeEnter: guardRoute
    },
    {
      path: '/actifio/enableDatabaseBackup',
      name: 'enableDatabaseBackup',
      meta: {
        breadcrumb: 'Enable Database Backup'
    },
      component: (resolve) => {
        require(['@/components/actifio/enableDatabaseBackup/Actifio/Actifio.vue'], resolve)
      },
     beforeEnter: guardRoute
    },
    {
      path: '/actifio/enableDatabase/mssqlTable',
      name: 'enableDatabaseBackupmssqlTable',
      meta: {
        breadcrumb: 'Enable Database Backup'
    },
      component: (resolve) => {
        require(['@/components/actifio/enableDatabaseBackup/mssqlTable/mssqlTable.vue'], resolve)
      },
    beforeEnter: guardRoute
    },
    {
      path: '/actifio/enableDatabaseBackup/oracle',
      name: 'enableDatabaseBackuporacle',
      meta: {
        breadcrumb: 'Enable Database Backup'
    },
      component: (resolve) => {
        require(['@/components/actifio/enableDatabaseBackup/oracle/oracle.vue'], resolve)
      },
     beforeEnter: guardRoute
    },
    {
      path: '/objectStorage',
      name: 'objectStorage',
      meta: {
        breadcrumb: 'ObjectStorage'
    },
      component: (resolve) => {
        require(['@/components/objectStorage/ObjectStorage.vue'], resolve)
      },
    beforeEnter: guardRoute
    },
    {
      path: '*',
      name: 'notfound',
      meta: {
        breadcrumb: 'Not Found'
    },
      component: (resolve) => {
        require(['@/components/notFound/NotFound.vue'], resolve)
      }
    }
  ]
})

function guardRoute (to, from, next) {
  // work-around to get to the Vuex store (as of Vue 2.0)
  router.app.showloader = false;
  const auth = router.app.$options.store.state.auth

  if (!auth.isLoggedIn) {
    next({
      path: '/login',
      query: { redirect: to.fullPath }
    })
  } else {
    next()
  }
}

export default router
