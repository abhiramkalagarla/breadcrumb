<template>
  <b-row>
  <b-col class="mt-10">
   <h2>Server Info</h2>
    <div>
    <b-form inline @submit="onSubmit">
      <label class="sr-only" for="formservername">serverName</label>
      <b-input class="mb-4 mr-sm-2 mb-sm-0" id="formcsid"
      @input="$v.form.serverName.$touch()"
                    v-model="form.serverName"
                    :state="!$v.form.serverName.$invalid"
       placeholder="Enter serverName" />
      <b-button type="submit" variant="primary" :disabled="$v.form.$invalid">Get Server Info</b-button>
    </b-form>
  </div>
</b-col>
<b-col md="12" v-if="serverInfo!=''">
{{serverInfo}}
</b-col>
</b-row>
</template>

<script>
import { validationMixin } from 'vuelidate'
import { required } from 'vuelidate/lib/validators'
export default {
  name: 'ServerInfo',
  data () {
    return {
      auth: this.$store.state.auth,
      form: {},
      serverInfo: ''
    }
  },
 mixins: [validationMixin],
  validations: {
    form: {
      serverName: {
        required
      }
    }
  },
  methods: {
    onSubmit (e) {
      e.preventDefault()
      this.getserverInfo()
    },
    getserverInfo () {
      const apiheaders = {
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json'
  }
}
      const infoProps = {
        'action': 'com.citi.cloud.oms/getServerInfo',
        'parameters': {
          'serverName': this.form.serverName
          }
          }
          
      this.$http
        .get('/api/servers?serverName=' + this.form.serverName, apiheaders)
        .then((response) => {
          this.serverInfo = response;
        })
        .catch((response) => {
          console.log(response)
          // this.error = utils.getError(response)
        })
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.mt-10{
  margin-top:10px;
}

</style>
