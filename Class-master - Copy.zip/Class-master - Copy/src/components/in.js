authenticate() {
    // var url= 'https://vm-86ae-9639.nam.nsroot.net:6400/citistorage/sit/oms/execute',
     credentials= {
        'action' : 'com.citi.cloud.oms/authenticateUser',
        'parameters': {
          'domain': this.form.Domain,
          'soeID': this.form.SOEID,
          'password': this.form.Password
          }
         }
        
    this.$http.post(url, credentials, {
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json'
      }
    }).then(
      (data) => {
        console.log(data)
        },
        (err) => {
          console.log(err)
        })
  },
