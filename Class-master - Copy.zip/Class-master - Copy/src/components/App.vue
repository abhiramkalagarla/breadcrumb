<template>
  <div id="app">
    <app-nav></app-nav>
    <div class="container-fluid app-content">
      <breadcrumbs/>
      <div class="holder" v-if="this.$root.showloader">
      <div class="preloader">
      <div></div>
      <div></div>
      <div></div>
      <div></div>
      <div></div>
      <div></div>
      <div></div>
      <div></div>
      <div></div><div></div>
      </div>
      </div>
      <router-view></router-view>
    </div>
  </div>

</template>

<script>
import AppNav from './AppNav.vue'
export default {
  name: 'appMain',
  components: { AppNav },
  created: function () {

  },
  data () {
    return {
      
    }
  }
}
</script>

<style lang="scss">

</style>
