<template>
    <div>
        <h3>{{$route.params.clustername}} - Details</h3>
        <b-button @click="clusterVolumes()" variant="primary" class="mb-4">List Volumes</b-button>
        <b-button @click="clusterSDCs()" variant="primary" class="mb-4">List SDCs</b-button>

        <div v-if="showvolumes">
            <table class=" table table-striped table-bordered table-hover">
                <thead><tr>
                    <th>
                        <span title="" >List of Volumes</span>
                    </th>
                </tr>
                </thead>
                <tbody>
                    <tr v-if="volumesdata.length == 0"><td colspan="1" class="text-center">No matching records</td></tr>
                    <tr v-if="volumesdata.length > 0" v-for="(vol, i) in volumesdata" :key="i"><td >{{vol}}</td></tr>
                </tbody>
            </table>
        </div>

        <div v-if="showSDCs"><v-client-table :data="sdcsdata" :columns="sdcscolumns" :options="sdcsoptions"></v-client-table></div>

    </div>
</template>

<script src="./indCluster.js">

</script>
