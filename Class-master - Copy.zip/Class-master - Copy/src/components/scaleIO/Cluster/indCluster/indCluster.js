import { validationMixin } from 'vuelidate'
import { required } from 'vuelidate/lib/validators'
const apiheaders = {
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json',
          'x-ibm-client-id': '53b6ce72-6157-4bdb-b1ce-afdcfd1adce5',
          'x-ibm-client-secret': 'gV0bI3iU6uV1sN1lX2sD2iB8bC4dG4rT5rC3eF3kW3dC6nD0jY'
  }
}

export default {
    name: 'indCluster',
    data () {
      return {
        serverName: [],
        volumesdata: [],
        showchild: '',
        showvolumes: false,
        showSDCs: false,
        sdcsdata: [],
        sdcscolumns: ['sdcGUID', 'sdcHost'],
        volcolumns: ['List of Volumes'],
        sdcsoptions: {
          templates: {
      },
          headings: {
            sdcGUID: 'ID',
            sdcHost: 'Host'
          },
          text: {
              filter: 'Search  Virtual pools:',
              filterPlaceholder: 'Virtual pools...',
              limit: 'Entries per Page: '
          },
          perPage: 10,
          pagination: { chunk: 10, dropdown: false }
          // see the options API
      },
      voloptions: {
        templates: {
    },
        text: {
            filter: 'Search  Virtual pools:',
            filterPlaceholder: 'Virtual pools...',
            limit: 'Entries per Page: '
        },
        perPage: 10,
        pagination: { chunk: 10, dropdown: false }
        // see the options API
      }
    }
  },
    created () {
    },
methods: {
        clusterVolumes () {
          this.$root.showloader = true
          this.showSDCs = false;
          this.showvolumes = true;
          const infoProps = {
            'workflowSync': 'listSIOVolumesAdmin',
            CSIID: 'sioservice',
            'parameters': {
                'sioClusterName': this.$route.params.clustername
            }    
          }
          this.$http
            .post('/api/sioservice/vroproxy', infoProps, apiheaders)
            .then(response => {
              this.volumesdata = response.body;
              this.$root.showloader = false
            })
            .catch(response => {
              this.$root.showloader = false
              try {
                var body = JSON.parse(response)
                alert(body.error)
                } catch (response) { 
                    alert('There was an error POSTing to ' + '/api/sioservice/vroproxy' + ': ' + response.statusCode.toString())
                  }
            });
        },
        clusterSDCs () {
          this.$root.showloader = true
          this.showSDCs = true;
          this.showvolumes = false;
            const infoProps = {
                'workflowSync': 'listSDCsFromCluster',
                CSIID: 'sioservice',
                'parameters': {
                    'sioClusterName': this.$route.params.clustername
                }          
            }
            this.$http
              .post('/api/sioservice/vroproxy', infoProps, apiheaders)
              .then(response => {
                this.sdcsdata = response.body;
                console.log(response);
                this.$root.showloader = false
              })
              .catch(response => {
                this.$root.showloader = false
                try {
                  var body = JSON.parse(response)
                  alert(body.error)
                  } catch (response) { 
                      alert('There was an error POSTing to ' + '/api/sioservice/vroproxy' + ': ' + response.statusCode.toString())
                    }
              });
          }
        }
    }
