<template>
  <div class="mt-2">
    <h2 class="text-center">ScaleIO Cluster</h2><br>
      <v-client-table :data="tableData" :columns="columns" :options="options">
        <div slot="afterLimit" class="pull-right">
          <button @click="newcluster()" class="btn btn-success mr-2" >Add Cluster</button> 
          <button @click="deletecluster()" class="btn btn-danger" >Delete Cluster</button>
        </div>
        <template slot="actions" slot-scope="props">
          <div class="btn-group btn-group-sm mr-2">
            <b-link :to="{name:'indCluster',params:{clustername:props.row.sioClusterName}}" class="btn btn-primary">Details</b-link>
            <button @click="discovercluster(props.row)" class="btn btn-info" >Discover</button>
            <button @click="editcluster(props.row)" class="btn btn-secondary" >Edit</button>
          </div>
        </template>
      </v-client-table>

   <b-modal v-model="showModal" no-enforce-focus :hide-footer="hidefooter"  ref="myModalRef" :title="popupTitle"  @hidden="onHidden">
          <b-form-group id="Discover"
                      label="Cluster Name"
                      class="required"
                      label-for="disclusternameInput">
          <b-form-input id="disclusternameInput"
                      type="text"
                      v-model="currentItem.clusterName"
                      :state="null"
                      aria-describedby="disclusternameInput"
                      placeholder="Enter Cluster Name" />
          <b-form-invalid-feedback id="disclusternameInput">
            This is a required field
          </b-form-invalid-feedback>
          </b-form-group>

          <b-form-group id="Discover"
                      label="Enter the Tornado Generation the cluster is created"
                      class="required"
                      label-for="clustertypeInput">
          <b-form-select id="clustertypeInput"
                      :options="clusterType"
                      v-model="currentItem.clusterType"
                      :state="null"
                      aria-describedby="clustertypeInput"
                      placeholder="Enter Cluster Type" />
          <b-form-invalid-feedback id="clustertypeInput">
            This is a required field
          </b-form-invalid-feedback>
          </b-form-group>

          <b-form-group id="Discover"
                      label="Enter Data Center"
                      class="required"
                      label-for="datacenterInput">
          <v-select taggable :options="dataCenter" v-model="currentItem.dataCenter"></v-select>
          <b-form-invalid-feedback id="datacenterInput">
            This is a required field
          </b-form-invalid-feedback>
          </b-form-group>

          <b-button type="submit" variant="primary" @click="getdiscovercluster()" :disabled="$v.currentItem.$invalid">Submit</b-button>
          <b-button type="button" @click="hidemodal()" variant="default">Cancel</b-button>
    </b-modal>

    <b-modal v-model="updateShowModal" no-enforce-focus :hide-footer="hidefooter"  ref="myUpdateModalRef" :title="popupTitle"  @hidden="onHidden">
          <b-form-group id="UpdateCluster"
                  label="Enter Cluster Name"
                  class="required"
                  label-for="updateclusternameInput">
          <b-form-input id="updateclusternameInput"
                    type="text"
                    v-model="updateItem.clusterName"
                    :state="null"
                    aria-describedby="updateclusternameInput"
                    placeholder="Enter Cluster Name" />
          <b-form-invalid-feedback id="updateclusternameInput">
                This is a required field
          </b-form-invalid-feedback>
          </b-form-group>

          <b-form-group id="UpdateCluster"
                  label="Enter Cluster gateway VIP"
                  description= "Format: https://(gw-vip).<i>region</i>.nsroot.net"
                  class="required"
                  label-for="updategatewayInput">
          <b-form-input id="updategatewayInput"
                    type="text"
                    v-model="updateItem.host"
                    :state="null"
                    v-on:input="$v.updateItem.host.$touch()"
                    aria-describedby="updategatewayInput"
                    placeholder="Enter Host" />
          <b-form-invalid-feedback id="updategatewayInput">
                This is a required field
          </b-form-invalid-feedback>
          <span class="text-danger" v-if="!$v.updateItem.host.rootvalidation && $v.updateItem.host.$dirty">Please Enter a valid Host URL</span>
          </b-form-group>
          
          <b-form-group id="UpdateCluster"
                  label="ScaleIO Username"
                  description="FID that is used to perform ScaleIO tasks, not an SOEID"
                  class="required"
                  label-for="updateusernameInput">
          <b-form-input id="updateusernameInput"
                    type="text"
                    v-model="updateItem.userName"
                    :state="null"
                    aria-describedby="updateusernameInput"
                    placeholder="Enter User Name" />
          <b-form-invalid-feedback id="updateusernameInput">
                This is a required field
          </b-form-invalid-feedback>
          </b-form-group>

          <b-form-group id="UpdateCluster"
                  label="ScaleIO Password"
                  class="required"
                  label-for="updatepasswordInput">
          <b-form-input id="updatepasswordInput"
                    type="password"
                    v-model="updateItem.password"
                    :state="null"
                    aria-describedby="updatepasswordInput"
                    placeholder="Enter Password" />
          <b-form-invalid-feedback id="updatepasswordInput">
                This is a required field
          </b-form-invalid-feedback>
          </b-form-group>          

        <b-button type="submit" variant="primary" @click="updateCluster()">Submit</b-button>
        <b-button type="button" @click="hidemodal()" variant="default">Cancel</b-button>
    
    </b-modal>
    
    <b-modal  no-enforce-focus  :hide-footer="hidefooter"   ref="myDeleteModalRef" :title="'Delete Cluster'" >

        <b-form-group id="Delete"
                      label="Please select Cluster Name to delete"
                      class="required"
                      label-for="delclusternameInput">
          <b-form-select id="delclusternameInput"
                      :options="tableData"
                       text-field="sioClusterName"
                       value-field="id"
                      v-model="deleteclusterName"
                      :state="null"
                      aria-describedby="delclusternameInput"
                      placeholder="Select Cluster Name" />
          <b-form-invalid-feedback id="delclusternameInput">
            This is a required field
          </b-form-invalid-feedback>
          </b-form-group>

          <b-button type="submit" variant="primary" @click="delcheck()">OK</b-button>
          <b-button type="button" @click="hidecancelmodal()" variant="default">Cancel</b-button>
    </b-modal>

    <b-modal v-model="createShowModal" no-enforce-focus :hide-footer="hidefooter"  ref="myCreateModalRef" :title="popupTitle"  @hidden="onHidden">
          <b-form-group id="CreateCluster"
                  label="Enter Cluster Name"
                  class="required"
                  label-for="clusternameInput">
          <b-form-input id="clusternameInput"
                    type="text"
                    v-model="createItem.clusterName"
                    :state="null"
                    aria-describedby="clusternameInput"
                    placeholder="Enter Cluster Name" />
          <b-form-invalid-feedback id="clusternameInput">
                This is a required field
          </b-form-invalid-feedback>
          </b-form-group>
          
          <b-form-group id="CreateCluster"
                  label="Enter Cluster gateway VIP"
                  description= "Format: https://(gw-vip).<i>region</i>.nsroot.net"
                  class="required"
                  label-for="gatewayInput">
          <b-form-input id="gatewayInput"
                    type="text"
                    v-model="createItem.host"
                    :state="null"
                    v-on:input="$v.createItem.host.$touch()"
                    aria-describedby="gatewayInput"
                    placeholder="Enter Host" />
          <b-form-invalid-feedback id="gatewayInput">
                This is a required field
          </b-form-invalid-feedback>
          <span class="text-danger" v-if="!$v.createItem.host.rootvalidation && $v.createItem.host.$dirty">Please Enter a valid Host URL</span>
          </b-form-group>
          
          <b-form-group id="CreateCluster"
                  label="ScaleIO Username"
                  description="FID that is used to perform ScaleIO tasks, not an SOEID"
                  class="required"
                  label-for="usernameInput">
          <b-form-input id="usernameInput"
                    type="text"
                    v-model="createItem.userName"
                    :state="null"
                    aria-describedby="usernameInput"
                    placeholder="Enter User Name" />
          <b-form-invalid-feedback id="usernameInput">
                This is a required field
          </b-form-invalid-feedback>
          </b-form-group>

          <b-form-group id="CreateCluster"
                  label="ScaleIO Password"
                  class="required"
                  label-for="passwordInput">
          <b-form-input id="passwordInput"
                    type="password"
                    v-model="createItem.password"
                    :state="null"
                    aria-describedby="passwordInput"
                    placeholder="Enter Password" />
          <b-form-invalid-feedback id="passwordInput">
                This is a required field
          </b-form-invalid-feedback>
          </b-form-group>

        <b-button type="submit" variant="primary" :disabled="$v.createItem.$invalid" @click="createCluster()">Submit</b-button>
        <b-button type="button" @click="hidemodal()" variant="default">Cancel</b-button>
     
    </b-modal>

  </div>
</template>

<script src="./cluster.js">
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.mt-10{
  margin-top:10px;
}
</style>
