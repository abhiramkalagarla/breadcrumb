import { validationMixin } from 'vuelidate'
import { required, helpers } from 'vuelidate/lib/validators'
const apiheaders = {
  headers: {
    'Content-Type': 'application/json',
    Accept: 'application/json',
    'x-ibm-client-id': '53b6ce72-6157-4bdb-b1ce-afdcfd1adce5',
    'x-ibm-client-secret': 'gV0bI3iU6uV1sN1lX2sD2iB8bC4dG4rT5rC3eF3kW3dC6nD0jY'
}
}
const rootvalidation = value => {
return /^https?:\/\/[A-Za-z\-_0-9]+\.(nam|eur|apac)\.nsroot\.net$/i.test(value)
}

export default {
  name: 'Cluster',
  data () {
    return {
        theme: 'bootstrap4',
        showModal: false,
        hidefooter: true,
        popupTitle: 'New Item',
        currentItem: {},
        selectedcluster: {},
        createItem: {},
        updateItem: {},
        clusterName: [],
        clusterType: ['T++', 'T3', 'T4', 'T4.5', 'T5'],
        dataCenter: ['GTDC', 'SWDC', 'MWDC', 'RUTH', '390', 'JRDC', 'QRDC', 'RDC', 'FDC', 'HK-IAD', 'HK-Asia Tone', 'SG-CT2'],
        template: 'default',
       // desc: 'Format: https://<gw-vip>.nam.nsroot.net',
        columns: ['host', 'sioClusterName', 'actions'],
        tableData: [],
        options: {
            templates: {
        },
            headings: {
                host: 'ScaleIO Cluster gateway VIP',
                sioClusterName: 'Cluster Name'
            },
            text: {
                filter: 'Search  Virtual pools:',
                filterPlaceholder: 'Virtual pools...',
                limit: 'Entries per Page: '

            },
            perPage: 10,
            pagination: { chunk: 10, dropdown: false }
            // see the options API
        }
    }
  },
  mixins: [validationMixin],
  validations: {
    currentItem: {
      clusterName: {
        required
      },
      clusterType: {
        required
      },
      dataCenter: {
        required
      }
    },
    createItem: {
      userName: {
        required
      },
      host: {
        required,
        rootvalidation
      },
      password: {
        required
      },
      clusterName: {
        required
      }
    },
    updateItem: {
      userName: {
        required
      },
      host: {
        required,
        rootvalidation
      },
      password: {
        required
      },
      clusterName: {
        required
      }
    }
  },
  created () {
    this.getAllClusters();
  },
  methods: {
    newcluster () {
      this.createShowModal = true
      this.createItem = {}
      this.popupTitle = 'New Cluster' 
      this.$refs.myCreateModalRef.show()
    },
    editcluster (rowdata) {
      console.log(rowdata)
      this.selectedcluster = rowdata
      this.popupTitle = 'Update Cluster'
      this.updateItem.clusterName = rowdata.sioClusterName
      this.updateItem.host = rowdata.host
      this.$refs.myUpdateModalRef.show()
      },
    onHidden () {
      this.currentItem = {}
      this.popupTitle = 'Discover Cluster'
      this.showModal = false
    },
    hidemodal () {
      this.$refs.myModalRef.hide()
      this.$refs.myCreateModalRef.hide()
      this.$refs.myUpdateModalRef.hide()
      },
    hidecancelmodal () {
      this.$refs.myDeleteModalRef.hide()
      },
    discovercluster (data) {
        this.currentItem.clusterName = data.sioClusterName
        this.$refs.myModalRef.show()
      },
    deletecluster () {
      this.$refs.myDeleteModalRef.show()
    },

    delcheck () {
      if (confirm('Please confirm you want to delete Cluster?')) {
          this.delCluster()
      } else {
        this.$refs.myDeleteModalRef.hide()
      }
    },

    delCluster () {
      console.log(this.deleteclusterName)
      this.$root.showloader = true
      const infoProps = {
            'workflowSync': 'deleteSIOCluster',
            CSIID: 'sioservice',
            'parameters': {
              instanceId: this.deleteclusterName
            }
          }
      this.$http
        .post('/api/sioservice/vroproxy', infoProps, apiheaders)
        .then((response) => {
          console.log(response)
          if (response.body.result.string.value !== '[{"delete":" failed"}]') {
            this.$refs.myDeleteModalRef.hide()
            this.getAllClusters()
            alert('Cluster Deleted succesfully')
          } else {
            alert('Cluster Not Deleted')
          }
          this.$root.showloader = false
        })
        .catch((response) => {
          this.$root.showloader = false
          try {
            console.log(response)
            var body = JSON.parse(response)
            alert(body.error)
            } catch (response) { 
              console.log(response)
                alert('There was an error POSTing to ' + '/api/sioservice/vroproxy' + ': ' + response.statusCode.toString())
              }
        })
      },

    getAllClusters () {
      this.$root.showloader = true
      const infoProps = {
        'workflowSync': 'getSIOClusters',
        CSIID: 'sioservice',
        parameters: {}
          }
      this.$http
        .post('/api/sioservice/vroproxy', infoProps, apiheaders)
        .then((response) => {
         this.tableData = response.body;
         this.$root.showloader = false
        })
        .catch((response) => {
          this.$root.showloader = false
          try {
            var body = JSON.parse(response)
            alert(body.error)
            } catch (response) { 
                alert('There was an error POSTing to ' + '/api/sioservice/vroproxy' + ': ' + response.statusCode.toString())
              }
        })
    },

    getdiscovercluster () {
      this.$root.showloader = true
      const infoProps = {
        'workflowSync': 'autoAddSIOPools',
        CSIID: 'sioservice',
        parameters: {
          sioClusterName: this.currentItem.clusterName,
          sioClusterType: this.currentItem.clusterType,
          dataCenter: this.currentItem.dataCenter
        }
          }
      this.$http
        .post('/api/sioservice/vroproxy', infoProps, apiheaders)
        .then((response) => {
         alert('Storage Pools successfully added')
         this.$refs.myModalRef.hide()
         this.$root.showloader = false
        })
        .catch((response) => {
          this.$root.showloader = false
          alert('Storage Pools not added')
          try {
            var body = JSON.parse(response)
            alert(body.error)
            } catch (response) { 
                alert('There was an error POSTing to ' + '/api/sioservice/vroproxy' + ': ' + response.statusCode.toString())
              }
        })
    },

    createCluster () {
      this.$root.showloader = true
      var data = {'id': this.selectedcluster.id, 'username': this.createItem.userName, 'password': this.createItem.password, 'host': this.createItem.host, 'name': this.createItem.clusterName}
      const infoProps = {
        'workflowSync': 'addSIOCluster',
        CSIID: 'sioservice',
        parameters: {
          'data': JSON.stringify(data)
        }
          }
      this.$http
        .post('/api/sioservice/vroproxy', infoProps, apiheaders)
        .then((response) => {
          this.getAllClusters();
          this.$refs.myCreateModalRef.hide()
          this.$root.showloader = false
          alert('Cluster Successfully created')
        })
        .catch((response) => {
          this.$root.showloader = false
          alert('Cluster not created')
          this.$refs.myCreateModalRef.hide()
          try {
            var body = JSON.parse(response)
            alert(body.error)
            } catch (response) { 
                alert('There was an error POSTing to /api/sioservice/vroproxy')
              }
        })
    },

    updateCluster () {
      this.$root.showloader = true
      var data = {'id': this.selectedcluster.id,
                  'username': this.updateItem.userName,
                  'host': this.updateItem.host,
                  'password': this.updateItem.password,
                  'name': this.updateItem.clusterName}
      const infoProps = {
        'workflowSync': 'updateSIOCluster',
        CSIID: 'sioservice',
        parameters: {
          'data': JSON.stringify(data)
        }
          }
      this.$http
        .post('/api/sioservice/vroproxy', infoProps, apiheaders)
        .then((response) => {
          this.getAllClusters();
          this.$refs.myUpdateModalRef.hide()
          this.$root.showloader = false
          alert('Cluster Successfully Updated')
        })
        .catch((response) => {
          this.$root.showloader = false
          alert('Cluster not Updated')
          this.$refs.myUpdateModalRef.hide()
          try {
            var body = JSON.parse(response)
            alert(body.error)
            } catch (response) { 
                alert('There was an error POSTing to /api/sioservice/vroproxy')
              }
        })
    }
  }
}
