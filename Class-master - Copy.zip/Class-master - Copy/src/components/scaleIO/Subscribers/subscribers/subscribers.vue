<template>
  <div class="mt-3">
    <h2 class="text-center">Access Plan Subscribers</h2><br>
      <v-client-table :data="tableData" :columns="columns" :options="options">
        <div slot="afterLimit" class="pull-right">
          <button @click="newsubscriber()" class="btn btn-success" >Add</button>
          <button @click="deletesubscriber()" class="btn btn-danger" >Delete Subscriber</button>
        </div>
        <template slot="actions" slot-scope="props">
          <b-link :to="{name:'indSubscriber',params:{subscriberid:props.row.ACA}}" class="btn btn-primary mr-2">Details</b-link>
      <!--<button @click="deletesubscriber(props.row)" class="btn btn-danger" >Delete Subscriber</button>-->
        </template>
        <template slot="csiId" slot-scope="props">
          <a target="_blank" :href="'https://archcntr.nam.nsroot.net/archcntr/Tools/ETC/Areas/Applications/Webpages/BasicView.aspx?prodid='+props.row.csiId+'&mode=view'">{{props.row.csiId}}</a>
        </template>
      </v-client-table>

    <b-modal v-model="createShowModal" no-enforce-focus :hide-footer="hidefooter"  ref="myCreateModalRef" :title="popupTitle"  @hidden="onHidden">
          <b-form-group id="CreateSubscriber"
                  label="Subscriber Name"
                  class="required"
                  label-for="subscribernameInput">
          <b-form-input id="subscribernameInput"
                    type="text"
                    v-model="currentItem.ACAName"
                    :state="null"
                    aria-describedby="subscribernameInput"
                    placeholder="Enter Subscriber Name" />
          <b-form-invalid-feedback id="subscribernameInput">
                This is a required field
          </b-form-invalid-feedback>
          </b-form-group>

          <b-form-group id="CreateSubscriber"
                  label="Subscriber ID"
                  class="required"
                  label-for="subscriberidInput">
          <b-form-input id="subscribernameInput"
                    type="text"
                    v-model="currentItem.ACA"
                    :state="null"
                    aria-describedby="subscriberidInput"
                    placeholder="Enter Subscriber ID" />
          <b-form-invalid-feedback id="subscriberidInput">
                This is a required field
          </b-form-invalid-feedback>
          </b-form-group>

          <b-form-group id="CreateSubscriber"
                  label="Subscriber CSIID"
                  class="required"
                  label-for="subscribernameInput">
          <b-form-input id="subscribercsiidInput"
                    type="text"
                    v-model="currentItem.csiId"
                    :state="null"
                    aria-describedby="subscribercsiidInput"
                    placeholder="Enter Subscriber CSIID" />
          <b-form-invalid-feedback id="subscribercsiidInput">
                This is a required field
          </b-form-invalid-feedback>
          </b-form-group>

        <b-button type="submit" variant="primary" :disabled="$v.currentItem.$invalid" @click="createSubscriber()">Submit</b-button>
        <b-button type="button" @click="hidemodal()" variant="default">Cancel</b-button>
     
    </b-modal>

    <b-modal  no-enforce-focus  :hide-footer="hidefooter"   ref="myDeleteModalRef" :title="'DeleteSubscriber'" >
        <b-form-group id="Delete"
                  label="Please select the Subscriber Name to delete"
                  class="required"
                  label-for="subscriberidInput">
          <b-form-select id="subscriberidInput"
                      :options="tableData"
                      text-field="ACAName"
                      value-field="ACA"
                      v-model="deleteSubscriber"
                      :state="null"
                      aria-describedby="subscriberidInput" />
          <b-form-invalid-feedback id="subscriberidInput">
                This is a required field
          </b-form-invalid-feedback>
          </b-form-group>
        <b-button type="button" variant="primary" @click="delcheck()">OK</b-button>
        <b-button type="button" @click="hidecancelmodal()" variant="default">Cancel</b-button>
    </b-modal>

</div>
</template>

<script src="./subscribers.js">
</script>
