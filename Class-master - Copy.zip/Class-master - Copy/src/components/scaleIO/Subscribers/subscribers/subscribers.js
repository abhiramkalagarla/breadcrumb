import { validationMixin } from 'vuelidate'
import { required } from 'vuelidate/lib/validators'
const apiheaders = {
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json',
          'x-ibm-client-id': '53b6ce72-6157-4bdb-b1ce-afdcfd1adce5',
          'x-ibm-client-secret': 'gV0bI3iU6uV1sN1lX2sD2iB8bC4dG4rT5rC3eF3kW3dC6nD0jY'
  }
}
export default {
  name: 'subscribers',
  data () {
    return {
      showModal: false,
      hidefooter: true,
      popupTitle: 'New Item',
      theme: 'bootstrap4',
      currentItem: {},
      template: 'default',
      columns: ['ACA', 'ACAName', 'csiId', 'actions'],
      tableData: [],
      options: {
            templates: {
            },
            headings: {
              ACA: 'Subscriber ID',
              ACAName: 'Subscriber Name',
              csiId: 'CSIID'
            },
            text: {
                filter: 'Search pools:',
                filterPlaceholder: 'pools...',
                limit: 'Entries per Page: '
            },
            perPage: 10,
            pagination: { chunk: 10, dropdown: false }
            // see the options API
        }
    }
  },
  mixins: [validationMixin],
  validations: {
    currentItem: {
      ACA: {
        required
      },
      csiId: {
        required
      },
      ACAName: {
        required
      }
    }
  },
  created () {
     this.getAllSubscribers();
  },
  beforeDestroy () {
    this.$root.showloader = false
  },
  methods: {
    onHidden () {
      this.currentItem = {}
      this.popupTitle = 'New Subscriber'
      this.showModal = false
    },
    hidemodal () {
      this.$refs.myCreateModalRef.hide()
    },
    hidecancelmodal () {
      this.$refs.myDeleteModalRef.hide()
    },
    newsubscriber () {
        this.showModal = true
        this.currentItem = {}
        this.popupTitle = 'New Subscriber' 
        this.$refs.myCreateModalRef.show()
    },
    deletesubscriber () {
       // this.currentItem = data
        this.$refs.myDeleteModalRef.show()
      },
    getAllSubscribers () {
      this.$root.showloader = true
      const infoProps = {
        'workflowSync': 'listSIOSubscribers',
        CSIID: 'sioservice',
        parameters: {
          
        }
          }
          
      this.$http
        .post('/api/sioservice/vroproxy', infoProps, apiheaders)
        .then((response) => {
          this.tableData = response.body;
          this.$root.showloader = false
        })
        .catch((response) => {
          this.$root.showloader = false
          try {
            var body = JSON.parse(response)
            alert(body.error)
            } catch (response) { 
                alert('There was an error POSTing to ' + '/api/sioservice/vroproxy' + ': ' + response.statusCode.toString())
              }
        })
    },
    delcheck () {
      if (confirm('Please confirm you want to delete Subscriber?')) {
          this.delSubscriber()
      } else {
        this.$refs.myDeleteModalRef.hide()
      }
  },
    delSubscriber () {
      this.$root.showloader = true
      const infoProps = {
            'workflowSync': 'deleteSIOSubscriber',
            CSIID: 'sioservice',
            'parameters': {
              'subscriberId': this.deleteSubscriber
            }
          }
          
      this.$http
        .post('/api/sioservice/vroproxy', infoProps, apiheaders)
        .then((response) => {
          console.log(response)
            this.$refs.myDeleteModalRef.hide()
            this.getAllSubscribers()
            alert('Subscriber Deleted succesfully')
            this.$root.showloader = false
        })
        .catch((response) => {
          this.$root.showloader = false
          try {
            var body = JSON.parse(response)
            alert(body.error)
            } catch (response) { 
                alert('There was an error POSTing to ' + '/api/sioservice/vroproxy' + ': ' + response.statusCode.toString())
              }
          alert('Subscriber not Deleted')
        })
      },

      createSubscriber () {
        this.$root.showloader = true
        const infoProps = {
          'workflowSync': 'addSIOSubscriber',
          CSIID: 'sioservice',
          parameters: {
            'subscriberId': this.currentItem.ACA,
            'subscriberName': this.currentItem.ACAName,
            'subscriberCsiId': this.currentItem.csiId
          }
            }
            
        this.$http
          .post('/api/sioservice/vroproxy', infoProps, apiheaders)
          .then((response) => {
            this.getAllSubscribers();
            alert('Subscriber Successfully created')
            this.$refs.myCreateModalRef.hide()
            this.$root.showloader = false
          })
          .catch((response) => {
            this.$root.showloader = false
            alert('Subscriber not created')
            this.$refs.myCreateModalRef.hide()
            try {
              var body = JSON.parse(response)
              alert(body.error)
              } catch (response) { 
                  alert('There was an error POSTing to ' + '/api/sioservice/vroproxy' + ': ' + response.statusCode.toString())
                }
          })
        }
    }
}
