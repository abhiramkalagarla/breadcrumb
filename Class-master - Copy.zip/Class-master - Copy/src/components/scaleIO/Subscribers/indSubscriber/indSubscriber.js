import { validationMixin } from 'vuelidate'
import { required } from 'vuelidate/lib/validators'
const apiheaders = {
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json',
          'x-ibm-client-id': '53b6ce72-6157-4bdb-b1ce-afdcfd1adce5',
          'x-ibm-client-secret': 'gV0bI3iU6uV1sN1lX2sD2iB8bC4dG4rT5rC3eF3kW3dC6nD0jY'
  }
}
const eightvalidation = value => {
  return value % 8 == 0
  }
export default {
  name: 'indSubscribers',
  data () {
    return {
      showModal: false,
      hidefooter: true,
      popupTitle: 'New Item',
      theme: 'bootstrap4',
      currentItem: {},
      deleteItem: {},
      updateItem: {},
      template: 'default',
      columns: ['AP', 'quota', 'usage', 'actions'],
      tableData: [],
      virtualpooldata: [],
      options: {
            templates: {
            },
            headings: {
                AP: 'Access Plan Name',
                quota: 'Quota(GB)',
                usage: 'Usage'
            },
            text: {
                filter: 'Search pools:',
                filterPlaceholder: 'pools...',
                limit: 'Entries per Page: '
            },
            perPage: 10,
            pagination: { chunk: 10, dropdown: false }
            // see the options API
        }
    }
  },
  mixins: [validationMixin],
  validations: {
    currentItem: {
      ACA: {
        required
      },
      vpName: {
        required
      },
      quotaGB: {
        required,
        eightvalidation
      }
    },
    updateItem: {
      ACA: {
        required
      },
      vpName: {
        required
      },
      quotaGB: {
        required,
        eightvalidation
      }
    },
    deleteItem: {
      AP: {
        required
      }
    }
  },
  created () {  
     this.getAllQuotas();
     this.getAllVirtualPools();
  },
  methods: {
    onHidden () {
      this.currentItem = {}
      this.popupTitle = 'New Quota'
      this.showModal = false
    },
    hidemodal () {
      this.$refs.myCreateModalRef.hide()
    },
    hideupdatemodal () {
      this.$refs.myUpdateModalRef.hide()
    },
    hidecancelmodal () {
      this.$refs.myDeleteModalRef.hide()
    },
    newquota () {
        this.currentItem = {}
        this.currentItem.ACA = this.$route.params.subscriberid
        this.popupTitle = 'New Quota' 
        this.$refs.myCreateModalRef.show()
    },
    deletequota () {
       // this.currentItem = data
        this.$refs.myDeleteModalRef.show()
    },
    editquota (data) {
        this.updateItem = {}
        this.updateItem.ACA = this.$route.params.subscriberid
        this.updateItem.vpName = data.AP
        this.popupTitle = 'Update Quota'
        this.$refs.myUpdateModalRef.show()
    },

      getAllQuotas () {
        this.$root.showloader = true
      const infoProps = {
        'workflowSync': 'getSIOQuotasBySubscriber',
        CSIID: 'sioservice',
        parameters: {
            'subscriberId': this.$route.params.subscriberid
        }
          }
          
      this.$http
        .post('/api/sioservice/vroproxy', infoProps, apiheaders)
        .then((response) => {
          this.$root.showloader = false
          this.tableData = response.body;
        })
        .catch((response) => {
          this.$root.showloader = false
          try {
            var body = JSON.parse(response)
            alert(body.error)
            } catch (response) { 
                alert('There was an error POSTing to ' + '/api/sioservice/vroproxy' + ': ' + response.statusCode.toString())
              }
        })
    },  

    createQuota () {
      this.$root.showloader = true
        const infoProps = {
          'workflowSync': 'addSIOQuota',
          CSIID: 'sioservice',
          parameters: {
            'subscriberId': this.currentItem.ACA,
            'APName': this.currentItem.vpName,
            'quotaGB': this.currentItem.quotaGB
          }
            }
            
        this.$http
          .post('/api/sioservice/vroproxy', infoProps, apiheaders)
          .then((response) => {
            this.$root.showloader = false
            this.$refs.myCreateModalRef.hide()
            if (response.body.status == 'Error') {
            alert("Quota Already Exists / Couldn't create")
            } else {
            alert('Subscriber Quota Successfully created')
            this.$refs.myCreateModalRef.hide()
            this.getAllQuotas();
          }
          })
          .catch((response) => {
            this.$root.showloader = false
            alert('Quota not created')
            this.$refs.myCreateModalRef.hide()
            try {
              console.log(response)
              var body = JSON.parse(response)
              alert(body.error)
              } catch (response) { 
                console.log(response)
                  alert('There was an error POSTing to ' + '/api/sioservice/vroproxy' + ': ' + response.statusCode.toString())
                }
          })
        },

        getAllVirtualPools () {
          const infoProps = {
            'workflowSync': 'listSIOVPs',
            CSIID: 'sioservice',
            parameters: {
              
            }
              }
              
          this.$http
            .post('/api/sioservice/vroproxy', infoProps, apiheaders)
            .then((response) => {
              this.virtualpooldata = response.body;
            })
            .catch((response) => {
              try {
                var body = JSON.parse(response)
                alert(body.error)
                } catch (response) { 
                    alert('There was an error POSTing to ' + '/api/sioservice/vroproxy' + ': ' + response.statusCode.toString())
                  }
            })
        },

        delcheck () {
          if (confirm('Please confirm you want to delete Access Plan quota?')) {
              this.delQuota()
          } else {
            this.$refs.myDeleteModalRef.hide()
          }
      },

        delQuota () {
          this.$root.showloader = true
          const infoProps = {
                'workflowSync': 'deleteSIOQuota',
                CSIID: 'sioservice',
                'parameters': {
                  'subscriberId': this.$route.params.subscriberid,
                  'APName': this.deleteItem.AP
                }
              }
              
          this.$http
            .post('/api/sioservice/vroproxy', infoProps, apiheaders)
            .then((response) => {
              this.$root.showloader = false
              console.log(response)
                this.$refs.myDeleteModalRef.hide()
                this.getAllQuotas()
                alert('Quota Deleted succesfully')
            })
            .catch((response) => {
              this.$root.showloader = false
              try {
                var body = JSON.parse(response)
                alert(body.error)
                } catch (response) { 
                    alert('There was an error POSTing to ' + '/api/sioservice/vroproxy' + ': ' + response.statusCode.toString())
                  }
              alert('Subscriber not Deleted')
            })
          },

          getupdatequota () {
            this.$root.showloader = true
            const infoProps = {
                  'workflowSync': 'updateSIOQuota',
                  CSIID: 'sioservice',
                  'parameters': {
                    'subscriberId': this.updateItem.ACA,
                    'APName': this.updateItem.vpName,
                    'quotaGB': this.updateItem.quotaGB
                  }
                }
                
            this.$http
              .post('/api/sioservice/vroproxy', infoProps, apiheaders)
              .then((response) => {
                this.$root.showloader = false
                console.log(response)
                  this.$refs.myUpdateModalRef.hide()
                  this.getAllQuotas()
                  alert('Quota Updated Successfully')
              })
              .catch((response) => {
                this.$root.showloader = false
                try {
                  var body = JSON.parse(response)
                  alert(body.error)
                  } catch (response) { 
                      alert('There was an error POSTing to ' + '/api/sioservice/vroproxy' + ': ' + response.statusCode.toString())
                    }
                alert('Quota not Updated')
              })
            }
    }
}
