<template>
  <div>
    <v-client-table :data="tableData" :columns="columns" :options="options">
        <div slot="afterLimit" class="pull-right">
            <button @click="newquota()" class="btn btn-success">Create Quota</button> 
            <button @click="deletequota()" class="btn btn-danger">Delete Quota</button>
        </div>
        <template slot="actions" slot-scope="props">
                <button @click="editquota(props.row)" class="btn btn-info">Update</button>
        </template>
    </v-client-table>

    <b-modal v-model="createShowModal" no-enforce-focus :hide-footer="hidefooter"  ref="myCreateModalRef" :title="popupTitle"  @hidden="onHidden">
          <b-form-group id="CreateQuota"
                  label="Subscriber ID"
                  class="required"
                  label-for="subscribernameInput">
          <b-form-input id="subscriberidInput"
                    type="text"
                    v-model="currentItem.ACA"
                    :state="null"
                    aria-describedby="subscriberidInput"
                    placeholder="Enter Subscriber ID" />
          <b-form-invalid-feedback id="subscriberidInput">
                This is a required field
          </b-form-invalid-feedback>
          </b-form-group>

          <b-form-group id="CreateSubscriber"
                  label="Access Plan Name"
                  class="required"
                  label-for="subscribernameInput">
          <b-form-select id="accessplanInput"
                    :options="virtualpooldata"
                    text-field="vpName"
                     value-field="vpName"
                    v-model="currentItem.vpName"
                    :state="null"
                    aria-describedby="accessplanInput"
                    placeholder="Enter Access Plan Name" />
          <b-form-invalid-feedback id="accessplanInput">
                This is a required field
          </b-form-invalid-feedback>
          </b-form-group>

          <b-form-group id="CreateSubscriber"
                  label="Quota(GB)"
                  class="required"
                  label-for="subscribernameInput">
          <b-form-input id="quotaInput"
                    type="number"
                    v-model.number="currentItem.quotaGB"
                    :state="null"
                    v-on:input="$v.currentItem.quotaGB.$touch()"
                    aria-describedby="quotaInput"
                    placeholder="Quota in GB" />
          <b-form-invalid-feedback id="quotaInput">
                This is a required field
          </b-form-invalid-feedback>
          <span class="text-danger" v-if="!$v.currentItem.quotaGB.eightvalidation && $v.currentItem.quotaGB.$dirty">Please enter a number Multiple of 8</span>
          </b-form-group>

        <b-button type="submit" variant="primary" :disabled="$v.currentItem.$invalid" @click="createQuota()">Submit</b-button>
        <b-button type="button" @click="hidemodal()" variant="default">Cancel</b-button>
    </b-modal>

        <b-modal  no-enforce-focus  :hide-footer="hidefooter"   ref="myDeleteModalRef" :title="'Delete Quota'" >
                <b-form-group id="Delete"
                            label="Please select the Access Plan quota to delete"
                            class="required"
                            label-for="deletequotaInput">
                <b-form-select id="deletequotaInput"
                            :options="tableData"
                            text-field="AP"
                            value-field="AP"
                            v-model="deleteItem.AP"
                            :state="null"
                            aria-describedby="deletequotaInput"/>
                <b-form-invalid-feedback id="deletequotaInput">
                        This is a required field
                </b-form-invalid-feedback>
                </b-form-group>
        <b-button type="button" variant="primary" @click="delcheck()">OK</b-button>
        <b-button type="button" @click="hidecancelmodal()" variant="default">Cancel</b-button>
    </b-modal>

    <b-modal v-model="showModal" no-enforce-focus :hide-footer="hidefooter"  ref="myUpdateModalRef" :title="popupTitle"  @hidden="onHidden">
          <b-form-group id="Update"
                      label="Subscriber ID"
                      class="required"
                      label-for="updatesubscriberidInput">
          <b-form-input id="updatesubscriberidInput"
                      type="text"
                      v-model="updateItem.ACA"
                      :state="null"
                      aria-describedby="updatesubscriberidInput"
                      placeholder="Enter Subscriber ID" />
          <b-form-invalid-feedback id="updatesubscriberidInput">
            This is a required field
          </b-form-invalid-feedback>
          </b-form-group>

          <b-form-group id="Update"
                      label="Access Plan Name"
                      class="required"
                      label-for="updateApNameInput">
          <b-form-input id="updateApNameInput"
                      type="text"
                      v-model="updateItem.vpName"
                      :state="null"
                      aria-describedby="updateApNameInput"
                      placeholder="Enter Access Plan Name" />
          <b-form-invalid-feedback id="updateApNameInput">
            This is a required field
          </b-form-invalid-feedback>
          </b-form-group>

          <b-form-group id="Update"
                      label="Quota(GB)"
                      class="required"
                      label-for="updatequotaInput">
          <b-form-input id="updatequotaInput"
                      type="number"
                      v-model.number="updateItem.quotaGB"
                      :state="null"
                      aria-describedby="updatequotaInput"
                      placeholder="Enter Quota(GB)" />
          <b-form-invalid-feedback id="updatequotaInput">
            This is a required field
          </b-form-invalid-feedback>
          </b-form-group>

          <b-button type="submit" variant="primary" @click="getupdatequota()" :disabled="$v.updateItem.$invalid">Submit</b-button>
          <b-button type="button" @click="hideupdatemodal()" variant="default">Cancel</b-button>
    </b-modal>

</div>
</template>

<script src="./indSubscriber.js">
</script>
