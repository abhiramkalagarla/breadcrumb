<template>
    <div class="mt-3">
        <h2 class="text-center">VM Subscribers</h2><br>
            <a target="_blank" href="http://sd-8735-ca81/BIReports/powerbi/CloudInsightReportingApp">http://sd-8735-ca81/BIReports/powerbi/CloudInsightReportingApp</a>
    </div>
</template>

<script>
export default {
  name: 'VMSubscribers',
  data () {
    return {
    }
  }
}
</script>
