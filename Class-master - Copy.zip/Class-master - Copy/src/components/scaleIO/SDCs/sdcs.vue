<template>
  <div class="mt-2">
  <b-form>
  <b-row>
  <b-col md="8">
  <h2 class="text-center">SDCs</h2><br>
    <b-form-group id="sdcs"
                  label="Please Enter SDC ID"
                  class="required"
                  horizontal
                  :label-cols="4"
                  breakpoint="md"
                  label-for="sdcId">
                  <b-input-group>
    <b-form-input id="sdcId"
                    type="text"
                    v-model="currentItem.sdcGUID"
                    aria-describedby="sdcId"
                    placeholder="Enter SDC ID" />
                    <b-input-group-append>
                    <b-btn variant="primary" @click="listClusters()">Search</b-btn>
                    </b-input-group-append>
                    </b-input-group>
    </b-form-group>

            </b-col>
            </b-row>
        </b-form>
         <v-client-table :data="tableData" :columns="columns" :options="options"></v-client-table>
    </div>
</template>

<script src="./sdcs.js">
</script>
