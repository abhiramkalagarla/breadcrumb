import { validationMixin } from 'vuelidate'
import { required, helpers } from 'vuelidate/lib/validators'
const apiheaders = {
  headers: {
    'Content-Type': 'application/json',
    Accept: 'application/json',
    'x-ibm-client-id': '53b6ce72-6157-4bdb-b1ce-afdcfd1adce5',
    'x-ibm-client-secret': 'gV0bI3iU6uV1sN1lX2sD2iB8bC4dG4rT5rC3eF3kW3dC6nD0jY'
}
}

export default {
    name: 'Cluster',
    data () {
      return {
          theme: 'bootstrap4',
          hidefooter: true,
          clusterName: [],
          currentItem: {},
          template: 'default',
          columns: ['sdcHost', 'sdcId', 'sioClusterName'],
          tableData: [],
          options: {
              templates: {
          },
              headings: {
                sdcHost: 'SDC Host',
                sdcId: 'SDC Id',
                sioClusterName: 'Cluster Name'
              },
              text: {
                  filter: 'Search  Virtual pools:',
                  filterPlaceholder: 'Virtual pools...',
                  limit: 'Entries per Page: '
  
              },
              perPage: 10,
              pagination: { chunk: 10, dropdown: false }
              // see the options API
          }
      }
    },
    mixins: [validationMixin],
    validations: {
      currentItem: {
        sdcGUID: {
          required
        }
      }
    },
    created () {
     // this.listClusters();
    },
    methods: {
        listClusters () {
        this.$root.showloader = true
        const infoProps = {
          'workflowSync': 'listClustersFromSDC',
          CSIID: 'sioservice',
          parameters: {
            sdcGUID: this.currentItem.sdcGUID
          }
            }
            
        this.$http
          .post('/api/sioservice/vroproxy', infoProps, apiheaders)
          .then((response) => {
           this.tableData = response.body;
           this.$root.showloader = false
          })
          .catch((response) => {
            this.$root.showloader = false
            try {
              var body = JSON.parse(response)
              alert(body.error)
              } catch (response) { 
                  alert('There was an error POSTing to ' + '/api/sioservice/vroproxy' + ': ' + response.statusCode.toString())
                }
          })
      }
    }
  }
