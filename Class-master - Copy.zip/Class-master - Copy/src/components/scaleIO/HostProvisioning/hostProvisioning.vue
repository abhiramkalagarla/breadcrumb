<template>
  <div class="mt-2">
  <b-row>
  <b-col md="8">
  <h2 class="text-center">ScaleIO Host Provisioning</h2>
    <b-form-group id="Provisioning"
                  label="CSI Application ID"
                  class="required"
                  horizontal
                  :label-cols="4"
                  breakpoint="md"
                  label-for="csiidInput">
                  <b-input-group>
    <b-form-input id="csiidInput"
                    type="text"
                    v-model="provisioning.CSIID"
                    aria-describedby="csiidInput"
                    placeholder="Enter CSI App ID" />
                    <b-input-group-append>
                    <b-btn variant="primary" @click="getAppInfo">Lookup</b-btn>
                    </b-input-group-append>
                    </b-input-group>
    </b-form-group>
    <b-form-group id="Provisioning"
                  label="Billing ID"
                  class="required"
                  horizontal
                  :label-cols="4"
                  breakpoint="md"
                  label-for="billingIDInput">
    <b-form-select id="billingIDInput"
                  :options="billingId"
                  v-model="provisioning.billingID"
                  aria-describedby="billingIDInput"
                  placeholder="Billing ID" />
    </b-form-group>
    <b-form-group id="Provisioning"
                  label="Hostname"
                  description="SDC Alias"
                  class="required"
                  horizontal
                  :label-cols="4"
                  breakpoint="md"
                  label-for="hostnameInput">
    <b-form-input id="hostnameInput"
                  type="text"
                  v-model="provisioning.hostName"
                  aria-describedby="hostnameInput"
                  placeholder="Hostname" />
    </b-form-group>
    <b-form-group id="Provisioning"
                  label="SDC GUID"
                  class="required"
                  horizontal
                  :label-cols="4"
                  breakpoint="md"
                  label-for="guidInput">
    <b-form-input id="guidInput"
                    type="text"
                    v-model="provisioning.GUID"
                    aria-describedby="guidInput"
                    placeholder="SDC GUID" />
    </b-form-group>
    <b-form-group id="Provisioning"
                  class="required"
                  label="SIO Cluster Name"
                  horizontal
                  :label-cols="4"
                  breakpoint="md"
                  label-for="clusterNameInput">
      <b-form-select id="clusterNameInput"
                    :options="clusterName"
                    text-field="sioClusterName"
                    value-field="id"
                    v-model="provisioning.sioClusterName"
                    aria-describedby="clusterNameInput"
                    placeholder="SIO Cluster Name"/>
    </b-form-group>
    <b-form-group id="provisioning"
                  class="required"
                  label="List of Pools"
                  horizontal
                  :label-cols="4"
                  breakpoint="md"
                  label-for="listpoolsInput">
      <b-form-select id="listpoolsInput"
                    :options="listpools"
                    v-model="provisioning.poolsList"
                    aria-describedby="listpoolsInput"
                    placeholder="list of pools"/>
    </b-form-group>
    <b-form-group id="Provisioning"
                  label="Volume Size(GB)"
                  class="required"
                  horizontal
                  :label-cols="4"
                  breakpoint="md"
                  label-for="volumeSizeInput">
    <b-form-input id="volumeSizeInput"
                    type="number"
                    v-model.number="provisioning.volumeSize"
                    :state="null"
                    v-on:input="$v.provisioning.volumeSize.$touch()"
                    aria-describedby="volumeSizeInput"
                    placeholder="Volume Size" />
    <span class="text-danger" v-if="!$v.provisioning.volumeSize.negativeValidation && $v.provisioning.volumeSize.$dirty">Please Enter only Positive Numbers</span>
    <span class="text-danger" v-if="!$v.provisioning.volumeSize.decimalvalidation && $v.provisioning.volumeSize.$dirty && $v.provisioning.volumeSize.negativeValidation">Decimal numbers are not allowed</span>
    </b-form-group>
    <b-form-group id="Provisioning"
                  label="Number of Volumes"
                  class="required"
                  horizontal
                  :label-cols="4"
                  breakpoint="md"
                  label-for="volnumberInput">
    <b-form-input id="volnumberInput"
                    type="number"
                    v-model.number="provisioning.volNumber"
                    aria-describedby="volnumberInput"
                    placeholder="Number of Volumes" />
    </b-form-group>
    <b-form-group id="Provisioning"
                  label="Volume Label"
                  class="required"
                  horizontal
                  :label-cols="4"
                  breakpoint="md"
                  label-for="volLableInput">
    <b-form-input id="volLableInput"
                    type="text"
                    v-model="provisioning.volLabel"
                    aria-describedby="volLableInput"
                    placeholder="Volume Label" />
    </b-form-group>

</b-col>
</b-row>

<b-row>
<b-col  md="8" offset-md="4" class="mt-1">
        <button  class="btn btn-primary">Submit</button> 
</b-col>
</b-row>

</div>
</template>

<script src="./hostProvisioning.js">
</script>
