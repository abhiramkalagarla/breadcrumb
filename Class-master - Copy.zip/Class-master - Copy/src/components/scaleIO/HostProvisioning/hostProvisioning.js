import { validationMixin } from 'vuelidate'
import { required, helpers } from 'vuelidate/lib/validators'
const apiheaders = {
    headers: {
      'Content-Type': 'application/json',
      Accept: 'application/json',
      'x-ibm-client-id': '53b6ce72-6157-4bdb-b1ce-afdcfd1adce5',
      'x-ibm-client-secret': 'gV0bI3iU6uV1sN1lX2sD2iB8bC4dG4rT5rC3eF3kW3dC6nD0jY'
  }
  }

  const negativeValidation = value => {
    return value > 0 
    }
    const decimalvalidation = value => {
     return /^(0|[1-9]\d*)$/gm.test(value)
      }
  
  export default {
      name: 'Host Provisioning',
      data () {
        return {
            theme: 'bootstrap4',
            hidefooter: true,
            isValidCSIID: false, 
            provisioning: {},
            template: 'default',
            billingId: [],
            clusterName: [],
            listpools: []
        }
      },
      mixins: [validationMixin],
      validations: {
        provisioning: {
          CSIID: {
            required
          },
          billingID: {
            required
          },
          hostName: {
            required
          },
          GUID: {
            required
          },
          sioClusterName: {
            required
          },
          poolsList: {
            required
          },
          volumeSize: {
            required,
            negativeValidation,
            decimalvalidation
          },
          volNumber: {
            required
          },
          volLabel: {
            required
          }
        }
      },
      watch: {
        'provisioning.CSIID': function (val, oldVal) {
        this.billingId = []
          }
        },
      created () {
          this.getAllClusters();
        },
      methods: {
      getAppInfo () {
        const apiheaders = {
          headers: {
            'Content-Type': 'application/json'      
          }
        }          
        this.$http
          .get('/api/apps?CSIID=' + this.provisioning.CSIID, {}, apiheaders)
          .then((response) => {
           this.billingId = response.body.billingIDs
           if (response.body.billingIDs.length == 1) {
             this.actifio.billingId = response.body.billingIDs[0]
           } else {
            alert('Billing ID found, Please select below')
           }
           this.isValidCSIID = false;
          })
          .catch((response) => {
            this.isValidCSIID = true;
            console.log(response)
          })
      },

      getAllClusters () {
        this.$root.showloader = true
        const infoProps = {
          'workflowSync': 'getSIOClusters',
          CSIID: 'sioservice',
          parameters: {}
            }
        this.$http
          .post('/api/sioservice/vroproxy', infoProps, apiheaders)
          .then((response) => {
           this.clusterName = response.body;
           this.$root.showloader = false
          })
          .catch((response) => {
            this.$root.showloader = false
            try {
              var body = JSON.parse(response)
              alert(body.error)
              } catch (response) { 
                  alert('There was an error POSTing to ' + '/api/sioservice/vroproxy' + ': ' + response.statusCode.toString())
                }
          })
      }
    }
  }
