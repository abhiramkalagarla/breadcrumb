<template>
  <div class="mt-2">
    <h2 class="text-center">ScaleIO Pools</h2><br>
      <div slot="afterLimit" class="pull-right">
        <!-- <button @click="newpool()" class="btn btn-success">Add pool</button> -->
        <button @click="deletepool()" class="btn btn-danger">Delete Pool</button>
      </div>
    <v-client-table :data="tableData" :columns="columns" :options="options">
      <template slot="actions" slot-scope="props">
        <div class="btn-group btn-group-sm mr-2">
          <b-link :to="{name:'Citipool',params:{citipoolname:props.row.citiPoolName}}" class="btn btn-primary">Details</b-link>
          <button @click="verifypool(props.row)" class="btn btn-info">Verify Pool Space</button>
        </div>
      </template>
      <template slot="status(offline / online)" slot-scope="props">
        <div class="switch">
          <input v-bind:id="props.row.id" class="cmn-toggle cmn-toggle-round-flat" v-on:change=togglepool($event,props.row) 
            v-bind:checked="props.row.status=='offline'?false:true" 
            type="checkbox">
            <label v-bind:for="props.row.id"></label>
        </div>
      </template>
    </v-client-table>

  <b-modal v-model="showModal" no-enforce-focus :hide-footer="hidefooter"  ref="myModalRef" :title="popupTitle"  @hidden="onHidden">
      <form @submit.stop.prevent="handleSubmit">
          <b-form-group id="DataCenter"
                      label="Data Center"
                      class="required"
                      label-for="datacenterInput">
          <b-form-input id="datacenterInput"
                      type="text"
                      v-model="currentItem.dataCenter"
                      :state="null"
                      aria-describedby="datacenterInputt"
                      placeholder="Enter Data Center" />
          <b-form-invalid-feedback id="datacenterInput">
            This is a required field
          </b-form-invalid-feedback>
          </b-form-group>

          <b-form-group id="CitiPoolName"
                      label="Cluster"
                      class="required"
                      label-for="ClusterInput">
          <b-form-input id="ClusterInput"
                      type="text"
                      v-model="currentItem.cluster"
                      :state="null"
                      aria-describedby="ClusterInput"
                      placeholder="Enter Cluster" />
          <b-form-invalid-feedback id="Cluster">
            This is a required field
          </b-form-invalid-feedback>
          </b-form-group>

          <b-form-group id="CitiPoolName"
                      label="Pool Name"
                      class="required"
                      label-for="poolnameInput">
          <b-form-input id="poolnameInput"
                      type="text"
                      v-model="currentItem.poolName"
                      :state="null"
                      aria-describedby="poolnameInput"
                      placeholder="Enter Pool Name" />
          <b-form-invalid-feedback id="poolnameInput">
            This is a required field
          </b-form-invalid-feedback>
          </b-form-group>

          <b-form-group id="PoolTier"
                    label="Pool Tier"
                    class="required"
                    label-for="pooltierInput">
          <b-form-input id="pooltierInput"
                    type="text"
                    v-model="currentItem.poolTier"
                    :state="null"
                    aria-describedby="pooltierInput"
                    placeholder="Enter Pool Tier" />
          <b-form-invalid-feedback id="pooltierInput">
            This is a required field
          </b-form-invalid-feedback>
          </b-form-group>

          <b-form-group id="PoolType"
                    label="Pool Type"
                    class="required"
                    label-for="pooltypeInput">
          <b-form-input id="pooltypeInput"
                      type="text"
                      v-model="currentItem.poolType"
                      :state="null"
                      aria-describedby="pooltypeInput"
                      placeholder="Enter Pool Type" />
          <b-form-invalid-feedback id="pooltypeInput">
            This is a required field
          </b-form-invalid-feedback>
          </b-form-group>

          <b-button type="submit" variant="primary" :disabled="$v.currentItem.$invalid">Submit</b-button>
          <b-button type="button" @click="hidemodal()" variant="default">Cancel</b-button>
      </form>
    </b-modal>

    <b-modal  no-enforce-focus  :hide-footer="hidefooter"   ref="myDeleteModalRef" :title="'Delete Pool'" >
     <b-form-group id="Delete"
                    label="Please select the Pool to delete"
                    description="Pool should be Offline before deleting, Only Offline pools are available in the dropdown"
                    class="required"
                    label-for="deletepoolInput">
          <b-form-select id="deletepoolInput"
                      :options="offlinetableData"
                       text-field="citiPoolName"
                       value-field="citiPoolName"
                      v-model="deleteCitiPool"
                      :state="null"
                      aria-describedby="deletepoolInput"/>
          <b-form-invalid-feedback id="deletepoolInput">
            This is a required field
          </b-form-invalid-feedback>
          </b-form-group>

    <b-button type="button" variant="primary" @click="delcheck()">OK</b-button>
    <b-button type="button" @click="hidecancelmodal()" variant="default">Cancel</b-button>
    </b-modal>

    <b-modal v-model="verifyShowModal" no-enforce-focus :hide-footer="hidefooter"  ref="myverifyModalRef" :title="popupTitle"  @hidden="onHidden">
          <b-form-group id="VerifyPool"
                  label="Cluster Name"
                  class="required"
                  label-for="clusternameInput">
          <b-form-input id="clusternameInput"
                    type="text"
                    v-model="verifyItem.clusterName"
                    :state="null"
                    aria-describedby="clusternameInput"
                    placeholder="Enter Cluster Name" />
          <b-form-invalid-feedback id="clusternameInput">
                This is a required field
          </b-form-invalid-feedback>
          </b-form-group>

          <b-form-group id="VerifyPool"
                  label="Citi Pool Name"
                  class="required"
                  label-for="clusternameInput">
          <b-form-input id="citipoolnameInput"
                    type="text"
                    v-model="verifyItem.citiPoolName"
                    :state="null"
                    aria-describedby="citipoolnameInput"
                    placeholder="Enter Citi Pool Name" />
          <b-form-invalid-feedback id="citipoolnameInput">
                This is a required field
          </b-form-invalid-feedback>
          </b-form-group>

          <b-form-group id="VerifyPool"
                  label="Enter Volume size (GB)"
                  class="required"
                  label-for="clusternameInput">
          <b-form-input id="volumesizeInput"
                    type="number"
                    v-model.number="verifyItem.volumeSize"
                    :state="null"
                    aria-describedby="volumesizeInput"
                    placeholder="Enter Volume Size" />
          <b-form-invalid-feedback id="volumesizeInput">
                This is a required field
          </b-form-invalid-feedback>
          </b-form-group>

          <b-form-group id="VerifyPool"
                  label="Enter Volume Quantity"
                  class="required"
                  label-for="clusternameInput">
          <b-form-input id="volumequantityInput"
                    type="number" min="0"
                    v-model.number="verifyItem.volumeQuantity"
                    :state="null"
                    v-on:input="$v.verifyItem.volumeQuantity.$touch()"
                    aria-describedby="volumequantityInput"
                    placeholder="Enter Volume Quantity" />
          <b-form-invalid-feedback id="volumequantityInput">
                This is a required field
          </b-form-invalid-feedback>
          <span class="text-danger" v-if="!$v.verifyItem.volumeQuantity.negativeValidation && $v.verifyItem.volumeQuantity.$dirty">Please Enter only Positive Numbers</span>
          <span class="text-danger" v-if="!$v.verifyItem.volumeQuantity.decimalvalidation && $v.verifyItem.volumeQuantity.$dirty && $v.verifyItem.volumeQuantity.negativeValidation">Decimal numbers are not allowed</span>
          </b-form-group>

        <b-button type="submit" variant="primary" :disabled="$v.verifyItem.$invalid" @click="verifyPoolSpace()">Submit</b-button>
        <b-button type="button" @click="hidemodal()" variant="default">Cancel</b-button>
     </b-modal>

  </div>
</template>

<script src="./pools.js">

</script>
<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.mt-10{
  margin-top:10px;
}
</style>
