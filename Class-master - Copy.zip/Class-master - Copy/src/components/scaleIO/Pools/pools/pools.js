import { validationMixin } from 'vuelidate'
import { required, helpers } from 'vuelidate/lib/validators'
const apiheaders = {
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json',
          'x-ibm-client-id': '53b6ce72-6157-4bdb-b1ce-afdcfd1adce5',
          'x-ibm-client-secret': 'gV0bI3iU6uV1sN1lX2sD2iB8bC4dG4rT5rC3eF3kW3dC6nD0jY'
  }
}
const negativeValidation = value => {
  return value > 0 
  }
  const decimalvalidation = value => {
   return /^(0|[1-9]\d*)$/gm.test(value)
   // return /^\d/i.test(value)
    }
export default {
  name: 'pools',
  data () {
    return {
      showModal: false,
      hidefooter: true,
      popupTitle: 'New Item',
      Deletepool: '',
      theme: 'bootstrap4',
      currentItem: {},
      verifyItem: {},
      template: 'default',
      columns: ['citiPoolName', 'cluster', 'status', 'poolName', 'actions'],
      tableData: [],
      offlinetableData: [],
      options: {
            templates: {
            },
            headings: {
                citiPoolName: 'Citi Pool Name',
                poolName: 'Pool Name'
            },
            text: {
                filter: 'Search pools:',
                filterPlaceholder: 'pools...',
                limit: 'Entries per Page: '
            },
            perPage: 10,
            pagination: { chunk: 10, dropdown: false }
            // see the options API
        }
    }
  },
  mixins: [validationMixin],
  validations: {
    currentItem: {
      cluster: {
        required
      },
      poolName: {
        required
      },
      datacenter: {
        required
      },
      poolTier: {
        required
      },
      poolType: {
        required
      }
    },
    verifyItem: {
      clusterName: {
        required
      },
      citiPoolName: {
        required
      },
      volumeSize: {
        required
      },
      volumeQuantity: {
        required,
        negativeValidation,
        decimalvalidation
      }
    }
  },
  created () {
     this.getAllPools();
  },
  methods: {
    onHidden () {
      this.currentItem = {}
      this.popupTitle = 'New Pool'
      this.showModal = false
    },
    hidemodal () {
      this.$refs.myModalRef.hide()
      this.$refs.myverifyModalRef.hide()
    },
    hidecancelmodal () {
      this.$refs.myDeleteModalRef.hide()
    },
    togglepool (ev, data) {
        this.startpool(data.citiPoolName, ev.target.checked)
        },
    newpool () {
        this.showModal = true
        this.currentItem = {}
        this.popupTitle = 'New Pool' 
        this.$refs.myModalRef.show()
    },
      editpool (data) {     
        this.showModal = true
        this.currentItem = data
        this.popupTitle = 'Edit Pool ' + data.citiPoolName
        this.$refs.myModalRef.show()
      },
      deletepool () {
       // this.currentItem = data
        this.$refs.myDeleteModalRef.show()
      },
      verifypool (data) {
        this.verifyShowModal = true
        this.verifyItem = {}
        this.popupTitle = 'Verify Pool Space' 
        this.verifyItem.clusterName = data.cluster
        this.verifyItem.citiPoolName = data.citiPoolName
        this.$refs.myverifyModalRef.show()
      },
      handleSubmit () {
        this.$root.showloader = true
        var cO = Object.assign({}, this.currentItem);
        const infoProps = {
            'workflowSync': 'addSIOPool',
            CSIID: 'sioservice',
            parameters: {

            },
            checkBypass: false,
            JSONPools: JSON.stringify(cO)
          }
          
      this.$http
        .post('/api/sioservice/vroproxy', infoProps, apiheaders)
        .then((response) => {
         // this.tableData = response.body;
          this.$root.showloader = false
        })
        .catch((response) => {
          this.$root.showloader = false
          try {
            var body = JSON.parse(response)
            alert(body.error)
            } catch (response) { 
                alert('There was an error POSTing to ' + '/api/sioservice/vroproxy' + ': ' + response.statusCode.toString())
              }
        })
      },

      startpool (poolname, set) {
        this.$root.showloader = true
          const infoProps = {
        'workflowSync': set ? 'enableSIOPool' : 'disableSIOPool',
        CSIID: 'sioservice',
        'parameters': {
        'citiPoolName': poolname
      }   
        }

          this.$http
        .post('/api/sioservice/vroproxy', infoProps, apiheaders)
        .then((response) => {
         // this.tableData = response.body;
          this.$root.showloader = false
        })
        .catch((response) => {
          this.$root.showloader = false
          try {
            var body = JSON.parse(response)
            alert(body.error)
            } catch (response) { 
                alert('There was an error POSTing to ' + '/api/sioservice/vroproxy' + ': ' + response.statusCode.toString())
              }
        })
      },

    getAllPools () {
      this.$root.showloader = true
      const infoProps = {
        'workflowSync': 'listSIOPools',
        CSIID: 'sioservice',
        parameters: {}
          }
          
      this.$http
        .post('/api/sioservice/vroproxy', infoProps, apiheaders)
        .then((response) => {
          this.tableData = response.body;
          this.offlinetableData = response.body.filter(function (el) {
            return el.status == 'offline'
          })
          this.$root.showloader = false
        })
        .catch((response) => {
          this.$root.showloader = false
          try {
            var body = JSON.parse(response)
            alert(body.error)
            } catch (response) { 
                alert('There was an error POSTing to ' + '/api/sioservice/vroproxy' + ': ' + response.statusCode.toString())
              }
        })
    },
delcheck () {
    if (confirm('Please confirm you want to delete Pool?')) {
        this.delPool()
    } else {
      this.$refs.myDeleteModalRef.hide()
    }
},
    delPool () {
      this.$root.showloader = true
      const infoProps = {
            'workflowSync': 'deleteSIOPool',
            CSIID: 'sioservice',
            'parameters': {
              'citiPoolName': this.deleteCitiPool
            }
          }
          
      this.$http
        .post('/api/sioservice/vroproxy', infoProps, apiheaders)
        .then((response) => {
          console.log(response)
            this.$refs.myDeleteModalRef.hide()
            this.getAllPools()
            alert('Pool Deleted succesfully')
            this.$root.showloader = false
        })
        .catch((response) => {
          this.$root.showloader = false
          try {
            var body = JSON.parse(response)
            alert(body.error)
            } catch (response) { 
                alert('There was an error POSTing to ' + '/api/sioservice/vroproxy' + ': ' + response.statusCode.toString())
              }
          alert('Pool not Deleted')
        })
      },

      verifyPoolSpace () {
        this.$root.showloader = true
        const infoProps = {
          'workflowSync': 'verifyPoolSpace',
          CSIID: 'sioservice',
          'parameters': {
            sioClusterName: this.verifyItem.clusterName,
            citiPoolName: this.verifyItem.citiPoolName,
            volumeSize: this.verifyItem.volumeSize,
            volumeQty: this.verifyItem.volumeQuantity
          }
        }
        
    this.$http
      .post('/api/sioservice/vroproxy', infoProps, apiheaders)
      .then((response) => {
        console.log(response)
        if (response.body.enoughSpace) {
          this.$refs.myverifyModalRef.hide()
          alert('There is currently sufficient space in this pool for the proposed provisioning event')
        } else {
          alert('Sorry! There is currently not sufficient space in this pool for the proposed provisioned event')
        }
        this.$root.showloader = false
      })
      .catch((response) => {
        this.$root.showloader = false
        try {
          var body = JSON.parse(response)
          alert(body.error)
          } catch (response) {
              alert('There was an error POSTing to /api/sioservice/vroproxy')
            }
      })
    }
  }
}
