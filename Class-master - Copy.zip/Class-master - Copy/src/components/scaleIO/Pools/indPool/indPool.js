import { validationMixin } from 'vuelidate'
import { required } from 'vuelidate/lib/validators'
const apiheaders = {
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json',
          'x-ibm-client-id': '53b6ce72-6157-4bdb-b1ce-afdcfd1adce5',
          'x-ibm-client-secret': 'gV0bI3iU6uV1sN1lX2sD2iB8bC4dG4rT5rC3eF3kW3dC6nD0jY'
  }
}
export default {
  name: 'indpools',
  data () {
    return {
    type: ['thin', 'thick'],
    poolDetails: [],
    showDetails: true,
    showtype: false,
    showCapacity: false,
    showEnable: false
    }
  },
  mixins: [validationMixin],
  validations: {
    poolDetails: {
      poolType: {
        required: this.showtype
      },
      antut: {
        required: this.showCapacity
      },
      maxoc: {
        required: this.showCapacity
      },
      maxut: {
        required: this.showCapacity
      },
      newage: {
        required: this.showCapacity
      },
      poolStatus: {
        required: this.showEnable
      }
      
    }
  },
  created () {
     this.getpoolDetails();
  },
  methods: {
    togglepool (ev) {
      this.$root.showloader = true
      var poolst = ev.target.checked
      this.poolDetails.poolStatus = poolst ? 'online' : 'offline'
      var endpoint = poolst ? 'enableSIOPool' : 'disableSIOPool'
      const infoProps = {
          'workflowSync': endpoint,
          CSIID: 'sioservice',
          'parameters': {
          'citiPoolName': this.$route.params.citipoolname
}
 }
this.$http
        .post('/api/sioservice/vroproxy', infoProps, apiheaders)
        .then((response) => {
          console.log(response);
          alert('Upated Succesfully')
          this.$root.showloader = false
        })
        .catch((response) => {
          this.$root.showloader = false
          try {
            var body = JSON.parse(response)
            alert(body.error)
            } catch (response) { 
                alert('There was an error POSTing to ' + '/api/sioservice/vroproxy' + ': ' + response.statusCode.toString())
              }
        })
    },
    updatepoolcapacity (e) {
      this.$root.showloader = true
      e.preventDefault()
      var capacity = [{'maxut': this.poolDetails.maxut, 'maxoc': this.poolDetails.maxoc, 'antut': this.poolDetails.antut, 'newage': this.poolDetails.newage}]
      const infoProps = {
        'workflowSync': 'editSIOPoolCapacity',
        CSIID: 'sioservice',
        'parameters': {
        'citiPoolName': this.$route.params.citipoolname,
        'capacityJSON': JSON.stringify(capacity)
}
 }
this.$http
        .post('/api/sioservice/vroproxy', infoProps, apiheaders)
        .then((response) => {
          console.log(response);
          alert('Capacity Upated Succesfully')
          this.$root.showloader = false
        })
        .catch((response) => {
          this.$root.showloader = false
          try {
            var body = JSON.parse(response)
            alert(body.error)
            } catch (response) { 
                alert('There was an error POSTing to ' + '/api/sioservice/vroproxy' + ': ' + response.statusCode.toString())
              }
        })
    },
    updatepooltype (e) {
      this.$root.showloader = true
      e.preventDefault()

      const infoProps = {
        'workflowSync': 'editSIOPoolType',
        CSIID: 'sioservice',
        'parameters': {
        'citiPoolName': this.$route.params.citipoolname,
        'poolType': this.poolDetails.poolType
}
 }
this.$http
        .post('/api/sioservice/vroproxy', infoProps, apiheaders)
        .then((response) => {
          console.log(response);
          alert('poolType Upated Succesfully')
          this.$root.showloader = false
        })
        .catch((response) => {
          this.$root.showloader = false
          try {
            var body = JSON.parse(response)
            alert(body.error)
            } catch (response) { 
                alert('There was an error POSTing to ' + '/api/sioservice/vroproxy' + ': ' + response.statusCode.toString())
              }
        })
    },
      enableAction (actionType) {
    switch (actionType) {
    case 'PT' :
    this.showDetails = false; this.showtype = true; this.showCapacity = false; this.showEnable = false
    break;
    case 'PC' :
    this.showDetails = false; this.showtype = false; this.showCapacity = true; this.showEnable = false
    break;
    case 'ED' :
    this.showDetails = false; this.showtype = false; this.showCapacity = false; this.showEnable = true
    break;
    case 'SD' :
    this.showDetails = true; this.showtype = false; this.showCapacity = false; this.showEnable = false
    break;
}
      },
    getpoolDetails () {
      this.$root.showloader = true
      const infoProps = {
        'workflowSync': 'getSIOPool',
        CSIID: 'sioservice',
        'parameters': {
        'citiPoolName': this.$route.params.citipoolname
}

          }
          
      this.$http
        .post('/api/sioservice/vroproxy', infoProps, apiheaders)
        .then((response) => {
          this.poolDetails = response.body[0];
          this.$root.showloader = false
        })
        .catch((response) => {
          this.$root.showloader = false
          try {
            var body = JSON.parse(response)
            alert(body.error)
            } catch (response) { 
                alert('There was an error POSTing to ' + '/api/sioservice/vroproxy' + ': ' + response.statusCode.toString())
              }
        })
    }
  }
}
