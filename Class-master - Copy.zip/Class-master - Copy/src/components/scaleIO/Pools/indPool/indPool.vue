<template>
  <div>
 <h3>{{$route.params.citipoolname}} - Details</h3>
 <b-button-group size="sm" class="mb-4">
    <b-button variant="primary" class="mr-2" @click="enableAction('PT')">Edit Pool Type</b-button>
    <b-button variant="primary" class="mr-2" @click="enableAction('PC')">Edit Capacity Check Parameters</b-button>
    <b-button variant="primary" class="mr-2" @click="enableAction('ED')">Online / Offline</b-button>
    <b-button v-if="!showDetails" variant="primary"  @click="enableAction('SD')">View Details</b-button>
  </b-button-group>
 <div class="row">
 <div class="col-md-8">
  
 <b-form v-if="showDetails">
      <b-form-group id="OfflinePools"
                    label="Pool Name"
                    horizontal
                    :label-cols="4"
                    breakpoint="md"
                    label-for="poolname">
      <b-form-input id="poolname"
                    type="text"
                    disabled
                    v-model="poolDetails.poolName"
                    aria-describedby="poolname"
                    placeholder="Pool Name" />
    </b-form-group>
    <b-form-group id="OfflinePools"
                    label="PoolTier"
                    horizontal
                    :label-cols="4"
                    breakpoint="md"
                    label-for="poolTier">
      <b-form-input id="poolTier"
                    type="text"
                    disabled
                    v-model="poolDetails.poolTier"
                    aria-describedby="poolTier"
                    placeholder="PoolTier" />
    </b-form-group>
    <b-form-group id="OfflinePools"
                    label="PoolType"
                    horizontal
                    :label-cols="4"
                    breakpoint="md"
                    label-for="poolType">
        <b-form-select id="poolType"
                    :options="type"
                    disabled="disabled"
                    v-model="poolDetails.poolType" />
     </b-form-group>
    <b-form-group id="OfflinePools"
                  label="Online/Offline"
                  horizontal
                  :label-cols="4"
                  breakpoint="md"
                  label-for="poolstatus">
      <b-form-input id="poolstatus"
                    type="text"
                    disabled
                    v-model="poolDetails.poolStatus"
                    aria-describedby="poolstatus"
                    placeholder="Online/Offline" />
    </b-form-group>
    <b-form-group id="OfflinePools"
                  label="sioClusterName"
                  horizontal
                  :label-cols="4"
                  breakpoint="md"
                  label-for="sioClusterName">
      <b-form-input id="poolname"
                    type="text"
                    disabled
                    v-model="poolDetails.sioClusterName"
                    aria-describedby="sioClusterName"
                    placeholder="sioClusterName" />
    </b-form-group>
    <b-form-group id="OfflinePools"
                  label="ClusterType"
                  horizontal
                  :label-cols="4"
                  breakpoint="md"
                  label-for="sioClusterType">
        <b-form-input id="sioClusterType"
                    type="text"
                    disabled
                    v-model="poolDetails.sioClusterType"
                    aria-describedby="sioClusterType"
                    placeholder="ClusterType" />
    </b-form-group>
    <b-form-group id="OfflinePools"
                  label="Data Center"
                  horizontal
                  :label-cols="4"
                  breakpoint="md"
                  label-for="datacenter">
      <b-form-input id="datacenter"
                    type="text"
                    disabled
                    v-model="poolDetails.dataCenter"
                    aria-describedby="datacenter"
                    placeholder="DataCenter" />
    </b-form-group>
    <b-form-group id="OfflinePools"
                  label="Anticipated Utilisation(antut)"
                  horizontal
                  :label-cols="4"
                  breakpoint="md"
                  label-for="antut">
      <b-form-input id="antut"
                    type="number"
                    disabled
                    v-model.number="poolDetails.antut"
                    aria-describedby="antut"
                    placeholder="antut" />
    </b-form-group>
    <b-form-group id="OfflinePools"
                  label="Max Utilisation (maxut)"
                  horizontal
                  :label-cols="4"
                  breakpoint="md"
                  label-for="maxut">
      <b-form-input id="maxut"
                    type="number"
                    disabled
                    v-model.number="poolDetails.maxut"
                    aria-describedby="maxut"
                    placeholder="maxut" />
    </b-form-group>
    <b-form-group id="OfflinePools"
                  label="Max Over Commitment (maxoc)"
                  horizontal
                  :label-cols="4"
                  breakpoint="md"
                  label-for="maxoc">
      <b-form-input id="maxoc"
                    type="number"
                    disabled
                    v-model.number="poolDetails.maxoc"
                    aria-describedby="maxoc"
                    placeholder="maxoc" />
    </b-form-group>
    <b-form-group id="OfflinePools"
                  label="Newage"
                  horizontal
                  :label-cols="4"
                  breakpoint="md"
                  label-for="newage">
      <b-form-input id="newage"
                    type="number"
                    disabled
                    v-model.number="poolDetails.newage"
                    aria-describedby="newage"
                    placeholder="newage" />
    </b-form-group>
    <b-form-group id="OfflinePools"
                  label="Pool ID"
                  horizontal
                  :label-cols="4"
                  breakpoint="md"
                  label-for="id">
      <b-form-input id="id"
                    type="text"
                    disabled
                    v-model="poolDetails.id"
                    aria-describedby="id"
                    placeholder="Pool ID" />
    </b-form-group>
    <b-form-group id="OfflinePools"
                  label="Citi Pool Name"
                  horizontal
                  :label-cols="4"
                  breakpoint="md"
                  label-for="citipoolname">
      <b-form-input id="citipoolname"
                    type="text"
                    disabled
                    v-model="poolDetails.citiPoolName"
                    aria-describedby="citipoolname"
                    placeholder="Citi Pool Name" />
    </b-form-group>
    <b-form-group id="OfflinePools"
                  label="sioSPId"
                  horizontal
                  :label-cols="4"
                  breakpoint="md"
                  label-for="sioSPId">
      <b-form-input id="sioSPId"
                    type="text"
                    disabled
                    v-model="poolDetails.sioSPId"
                    aria-describedby="sioSPId"
                    placeholder="sioSPId" />
    </b-form-group>
    <b-form-group id="OfflinePools"
                  label="sioPDId"
                  horizontal
                  :label-cols="4"
                  breakpoint="md"
                  label-for="sioPDId">
      <b-form-input id="sioPDId"
                    type="text"
                    disabled
                    v-model="poolDetails.sioPDId"
                    aria-describedby="sioPDId"
                    placeholder="sioPDId" />
    </b-form-group>
</b-form>
</div>
 </div>
 <div v-if="showtype">
 <h5>Update Pool Type</h5>
<div class="row">
<div class="col-md-8">
 <b-form @submit="updatepooltype">
    <b-form-group id="OfflinePools"
                  label="PoolType"
                  horizontal
                  :label-cols="4"
                  breakpoint="md"
                  label-for="poolType">
                  <b-form-select id="poolType"
                  :options="type"
                  v-model="poolDetails.poolType" />
    </b-form-group>
  <button  class="btn btn-primary" >Update</button>
</b-form>
</div>
 </div>
 </div>

 <div v-if="showCapacity">
 <h5>Update Pool Capacity</h5>
 <div class="row">
<div class="col-md-8">
 <b-form @submit="updatepoolcapacity">
  <b-form-group id="OfflinePools"
                  label="Anticipated Utilisation(antut)"
                  horizontal
                  :label-cols="4"
                  breakpoint="md"
                  label-for="antut">
      <b-form-input id="antut"
                    type="number"
                    v-model.number="poolDetails.antut"
                    aria-describedby="antut"
                    placeholder="antut" />
    </b-form-group>
    <b-form-group id="OfflinePools"
                  label="Max Over Commitment (maxoc)"
                  horizontal
                  :label-cols="4"
                  breakpoint="md"
                  label-for="maxoc">
      <b-form-input id="maxoc"
                    type="number"
                    v-model.number="poolDetails.maxoc"
                    aria-describedby="maxoc"
                    placeholder="maxoc" />
    </b-form-group>
    <b-form-group id="OfflinePools"
                  label="Max Utilisation (maxut)"
                  horizontal
                  :label-cols="4"
                  breakpoint="md"
                  label-for="maxut">
      <b-form-input id="maxut"
                    type="number"
                    v-model.number="poolDetails.maxut"
                    aria-describedby="maxut"
                    placeholder="maxut" />
    </b-form-group>
    <b-form-group id="OfflinePools"
                  label="Newage"
                  horizontal
                  :label-cols="4"
                  breakpoint="md"
                  label-for="newage">
      <b-form-input id="newage"
                    type="number"
                    v-model.number="poolDetails.newage"
                    aria-describedby="newage"
                    placeholder="newage" />
    </b-form-group>
  <button class="btn btn-primary" >Update</button>
 </b-form>
 </div>
 </div>
 </div>

 <div v-if="showEnable">
 <h5>Online / Offline</h5>
 <div class="switch">
            <input id="enablepool"  class="cmn-toggle cmn-toggle-round-flat" v-on:change=togglepool($event) 
            v-bind:checked="poolDetails.poolStatus=='offline'?false:true" 
            type="checkbox">
            <label for="enablepool"></label>
  </div>
 </div>
 
  </div>
</template>

<script src="./indPool.js">

</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.mt-10{
  margin-top:10px;
}
</style>
