<template>
<form @submit.stop.prevent="handleSubmit">
        <b-form-group id="CitiPoolName"
                  label="Citi Pool Name"
                  class="required"
                  label-for="poolnameInput">
      <b-form-input id="poolnameInput"
                    type="text"
                    v-model="form.citiPoolName"
                    :state="null"
                    aria-describedby="poolnameInput"
                    placeholder="Enter City Pool Name" />
      <b-form-invalid-feedback id="poolnameInput">
       This is a required field
      </b-form-invalid-feedback>
    </b-form-group>

    <b-form-group id="CitiPoolName"
                  label="Cluster"
                  class="required"
                  label-for="ClusterInput">
      <b-form-input id="ClusterInput"
                    type="text"
                    v-model="form.cluster"
                    :state="null"
                    aria-describedby="ClusterInput"
                    placeholder="Enter Cluster" />
      <b-form-invalid-feedback id="Cluster">
       This is a required field
      </b-form-invalid-feedback>
    </b-form-group>
    
      </form>
</template>

<script src="./popup.js">

</script>
