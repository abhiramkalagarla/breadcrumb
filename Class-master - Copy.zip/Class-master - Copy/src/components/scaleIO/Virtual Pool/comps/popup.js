import { validationMixin } from 'vuelidate'
import { required } from 'vuelidate/lib/validators'
  export default {
      name: 'popup',
      props: ['formdata'],
    data () {
      return {
          form: Object.assign({}, this.formdata)
      }
    },
    mixins: [validationMixin],
    methods: {
    clearName () {

    },
      handleOk (evt) {
          alert('a')
      evt.preventDefault()
    },
    handleSubmit () {
      this.$refs.modal.hide()
    }
    }
  }
