<template>
  <div>
 <h3>{{$route.params.vpID}} - Details</h3>

 <div class="row">
 <div class="col-md-7">

 <b-form v-if="showDetails">
        <b-form-group id="OfflinePools"
                  label="Access Plan ID"
                  horizontal
                  :label-cols="4"
                  breakpoint="md"
                  label-for="id">
        <b-form-input id="id"
                    type="text"
                    disabled
                    v-model="virtualpoolDetails.id"
                    aria-describedby="id"
                    placeholder="Access Plan ID" />
        </b-form-group>
       <b-form-group id="OfflinePools"
                  label="Access Plan Data Center"
                  horizontal
                  :label-cols="4"
                  breakpoint="md"
                  label-for="dataCenter">
      <b-form-input id="dataCenter"
                    type="text"
                    disabled
                    v-model="virtualpoolDetails.dataCenter"
                    aria-describedby="dataCenter"
                    placeholder="Access Plan Data Center" />
    </b-form-group>
    <b-form-group id="OfflinePools"
                  label="Access Plan Name"
                  horizontal
                  :label-cols="4"
                  breakpoint="md"
                  label-for="vpName">
      <b-form-input id="vpName"
                    type="text"
                    disabled
                    v-model="virtualpoolDetails.vpName"
                    aria-describedby="vpName"
                    placeholder="Access Plan Name" />
    </b-form-group>
    <b-form-group id="OfflinePools"
                  label="Access Plan Status"
                  horizontal
                  :label-cols="4"
                  breakpoint="md"
                  label-for="vpStatus">
      <b-form-input id="vpStatus"
                    type="text"
                    disabled
                    v-model="virtualpoolDetails.vpStatus"
                    aria-describedby="vpStatus"
                    placeholder="Virtual Pool Status" />
    </b-form-group>
    <b-form-group id="OfflinePools"
                  label="Access Plan Tier"
                  horizontal
                  :label-cols="4"
                  breakpoint="md"
                  label-for="vpTier">
      <b-form-input id="vpTier"
                    type="text"
                    disabled
                    v-model="virtualpoolDetails.vpTier"
                    aria-describedby="vpTier"
                    placeholder="Access Plan Tier" />
    </b-form-group>
  <!-- <b-form-group id="OfflinePools"
                  label="Offline Pools"
                  horizontal
                  :label-cols="4"
                  breakpoint="md"
                  label-for="offlinePools">
      <b-form-input id="offlinePools"
                    type="text"
                    disabled
                    v-model="virtualpoolDetails.offlinePools"
                    aria-describedby="offlinePools"
                    placeholder="Offline Pools" />
    </b-form-group>
    <b-form-group id="OfflinePools"
                  label="Online Pools"
                  horizontal
                  :label-cols="4"
                  breakpoint="md"
                  label-for="onlinePools">
      <b-form-input id="onlinePools"
                    type="text"
                    disabled
                    v-model="virtualpoolDetails.onlinePools"
                    aria-describedby="onlinePools"
                    placeholder="Online Pools" />
    </b-form-group> -->

    <table class=" table table-striped table-bordered table-hover">
                <thead><tr>
                    <th>
                        <span title="" >Offline Pools</span>
                    </th>
                    <th>Action(offline / online)</th>
                </tr>
                </thead>
                <tbody>
                    <tr v-if="offlineData.length == 0"><td colspan="2" class="text-center">No matching records</td></tr>
                    <tr v-if="offlineData.length > 0" v-for="(vol, i) in offlineData" :key="i">
                    <td >{{vol}}</td>
                    <td>
                    <div class="switch">
            <input v-bind:id="i" class="cmn-toggle cmn-toggle-round-flat" v-on:change=togglepool(vol,true) 
            v-bind:checked="false"
            type="checkbox">
            <label v-bind:for="i"></label>
          </div>
              </td>
            </tr>
          </tbody>
      </table>

      <table class=" table table-striped table-bordered table-hover">
                <thead><tr>
                    <th>
                        <span title="" >Online Pools</span>
                    </th>
                    <th>Action(offline / online)</th>
                </tr>
                </thead>
                <tbody>
                    <tr v-if="onlineData.length == 0"><td colspan="2" class="text-center">No matching records</td></tr>
                    <tr v-if="onlineData.length > 0" v-for="(vol, i) in onlineData" :key="i">
                    <td >{{vol}}</td>
                    <td>
                    <div class="switch">
            <input v-bind:id="i" class="cmn-toggle cmn-toggle-round-flat" v-on:change=togglepool(vol,false) 
            v-bind:checked="true"
            type="checkbox">
            <label v-bind:for="i"></label>
          </div>
                    </td>
                    </tr>
                </tbody>
            </table>

 </b-form>
 </div>
 </div>
    <v-client-table :data="tableData" :columns="columns" :options="options"></v-client-table>

</div>
</template>

<script src="./indVirtualPool.js">
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.mt-10{
  margin-top:10px;
}
</style>
