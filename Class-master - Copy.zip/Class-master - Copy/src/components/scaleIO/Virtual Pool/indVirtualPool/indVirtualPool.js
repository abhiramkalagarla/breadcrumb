import { validationMixin } from 'vuelidate'
import { required } from 'vuelidate/lib/validators'
const apiheaders = {
  headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json',
          'x-ibm-client-id': '53b6ce72-6157-4bdb-b1ce-afdcfd1adce5',
          'x-ibm-client-secret': 'gV0bI3iU6uV1sN1lX2sD2iB8bC4dG4rT5rC3eF3kW3dC6nD0jY'}
          }
export default {
  name: 'indvirtualpools',
  data () {
    return {
    virtualpoolDetails: [],
    showDetails: true,
    appQuota: [],
    tableData: [],
    offlineData: [],
    onlineData: [],
    columns: ['AP', 'quota', 'usage'],
    options: {
      templates: {
      },
      headings: {
        AP: 'Access Plan Name',
        quota: 'Quota(GB)',
        usage: 'Usage'
      },
      text: {
          filter: 'Search pools:',
          filterPlaceholder: 'pools...',
          limit: 'Entries per Page: '
      },
      perPage: 10,
      pagination: { chunk: 10, dropdown: false }
      // see the options API
  }
    }
  },
  mixins: [validationMixin],
  validations: {
  },
  created () {
     this.getvirtualpoolDetails();
     this.getAppQuota();
     this.getAllQuotas();
  },

  methods: {
    togglepool (i, data) {
      this.toggleofflineonline(JSON.stringify([i]), data)
  },
      enableAction (actionType) {
  },
    getvirtualpoolDetails () {
      this.$root.showloader = true
      const infoProps = {
        'workflowSync': 'getSIOVP',
        CSIID: 'sioservice',
        'parameters': {
        'vpId': this.$route.params.vpID
            }
        }
          
      this.$http
        .post('/api/sioservice/vroproxy', infoProps, apiheaders)
        .then((response) => {
          this.virtualpoolDetails = response.body;
          this.offlineData = response.body.offlinePools;
          this.onlineData = response.body.onlinePools;
          this.$root.showloader = false
        })
        .catch((response) => {
          this.$root.showloader = false
          try {
            var body = JSON.parse(response)
            alert(body.error)
            } catch (response) { 
                alert('There was an error POSTing to ' + '/api/sioservice/vroproxy' + ': ' + response.statusCode.toString())
              }
        })
    },
    getAppQuota () {
      this.$root.showloader = true
      var vpIds = [this.$route.params.vpID]
      var action = 'getSIOQuota' || 'getSIOUsage' 
      const infoProps = {
        'workflowSync': action,
        CSIID: 'sioservice',
        'parameters': {
          'arrVps': JSON.stringify(vpIds)
        }
          }
          
      this.$http
        .post('/api/sioservice/vroproxy', infoProps, apiheaders)
        .then((response) => {
          this.appQuota = response.body;
          this.$root.showloader = false
        })
        .catch((response) => {
          this.$root.showloader = false
          try {
            var body = JSON.parse(response)
            alert(body.error)
            } catch (response) { 
                alert('There was an error POSTing to ' + '/api/sioservice/vroproxy' + ': ' + response.statusCode.toString())
              }
        })
    },
  toggleofflineonline (pools, set) {
    this.$root.showloader = true
      const infoProps = {
        'workflowSync': set ? 'setOnlinePools' : 'setOfflinePools',
        CSIID: 'sioservice',
        'parameters': {
        'vpId': this.$route.params.vpID
            }
        }
        set ? infoProps.parameters.onlinePools = pools : infoProps.parameters.offlinePools = pools
          
      this.$http
        .post('/api/sioservice/vroproxy', infoProps, apiheaders)
        .then((response) => {
          this.getvirtualpoolDetails();
          this.$root.showloader = false
        })
        .catch((response) => {
          this.$root.showloader = false
          try {
            var body = JSON.parse(response)
            alert(body.error)
            } catch (response) { 
                alert('There was an error POSTing to ' + '/api/sioservice/vroproxy' + ': ' + response.statusCode.toString())
              }
        })
    },
    getAllQuotas () {
      this.$root.showloader = true
    const infoProps = {
      'workflowSync': 'getSIOQuotasByAP',
      CSIID: 'sioservice',
      parameters: {
          'APName': this.$route.params.vpName
      }
        }
        
    this.$http
      .post('/api/sioservice/vroproxy', infoProps, apiheaders)
      .then((response) => {
        this.tableData = response.body;
        this.$root.showloader = false
      })
      .catch((response) => {
        this.$root.showloader = false
        try {
          var body = JSON.parse(response)
          alert(body.error)
          } catch (response) { 
              alert('There was an error POSTing to ' + '/api/sioservice/vroproxy' + ': ' + response.statusCode.toString())
            }
      })
  }
  }
}
