import { validationMixin } from 'vuelidate'
import { required } from 'vuelidate/lib/validators'
import popup from '../comps/popup.vue'
const apiheaders = {
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json',
          'x-ibm-client-id': '53b6ce72-6157-4bdb-b1ce-afdcfd1adce5',
          'x-ibm-client-secret': 'gV0bI3iU6uV1sN1lX2sD2iB8bC4dG4rT5rC3eF3kW3dC6nD0jY'
  }
}
export default {
  name: 'virtualpools',
  components: { popup },
  data () {
    return {
        showModal: false,
        hidefooter: true,
        popupTitle: 'New Item',
        theme: 'bootstrap4',
        currentItem: {},
        template: 'default',
        OPools: [],
        dataCenter: ['GTDC', 'SWDC', 'MWDC', 'RUTH', '390', 'JRDC', 'QRDC', 'RDC', 'FDC', 'HK-IAD', 'HK-Asia Tone', 'SG-CT2'],
        poolTier: ['SSD', 'SAS', 'HPF', 'GPF'],
        columns: ['id', 'vpName', 'status (offline / online)', 'actions'],
        tableData: [],
        DeletevirtualPool: '',
        options: {
            templates: {
        },
            headings: {
                id: 'Access Plan ID',
                vpName: 'Access Plan Name'
            },
            text: {
                filter: 'Search  Virtual pools:',
                filterPlaceholder: 'Virtual pools...',
                limit: 'Entries per Page: '

            },
            perPage: 10,
            pagination: { chunk: 10, dropdown: false }
            // see the options API
        }
    }
  },
  mixins: [validationMixin],
  validations: {
    currentItem: {
      vpName: {
        required
      },
      onlinePools: {
        required
      },
      poolTier: {
        required
      },
      dataCenter: {
        required
      }
    }
  },
  created () {
     this.getAllVirtualPools();
     this.getOnlinePools();
  },
  methods: {
    onHidden () {
      this.currentItem = {}
      this.popupTitle = 'New Plan'
      this.showModal = false
    },
    newpool () {
        this.showModal = true
        this.currentItem = {}
        this.popupTitle = 'New Access Plan' 
        this.$refs.myModalRef.show()
    },
    hidemodal () {
    this.$refs.myModalRef.hide()
    },
    hidecancelmodal () {
    this.$refs.myDeleteModalRef.hide()
    },
    toggleplan (ev, data) {
     this.startplan(data.id, ev.target.checked)
    },
    editpool (data) {     
      this.showModal = true
      this.currentItem = data
      this.popupTitle = 'Edit Pool ' + data.citiPoolName
      this.$refs.myModalRef.show()
    },
    deletepool () {
       // this.currentItem = data
        this.$refs.myDeleteModalRef.show()
      },
      delcheck () {
        if (confirm('Please confirm you want to delete Access Plan?')) {
            this.delVPool()
        } else {
          this.$refs.myDeleteModalRef.hide()
        }
    },
      delVPool () {
        this.$root.showloader = true
      const infoProps = {
            'workflowSync': 'deleteSIOVP',
            CSIID: 'sioservice',
            'parameters': {
              'vpId': this.deleteVirtualPool
            }
          }
          
      this.$http
        .post('/api/sioservice/vroproxy', infoProps, apiheaders)
        .then((response) => {
          console.log(response)
          if (response.body.status === 'ok') {
            this.$refs.myDeleteModalRef.hide()
            this.getAllVirtualPools()
            alert('Access Plan Deleted succesfully')
            this.$root.showloader = false
          }
        })
        .catch((response) => {
          this.$root.showloader = false
          try {
            var body = JSON.parse(response)
            alert(body.error)
            } catch (response) { 
                alert('There was an error POSTing to ' + '/api/sioservice/vroproxy' + ': ' + response.statusCode.toString())
              }
        })
      },

      getOnlinePools () {
        this.$root.showloader = true
        const infoProps = {
            'workflowSync': 'listSIOPools',
            CSIID: 'sioservice',
            parameters: {
            }
          }
          
      this.$http
        .post('/api/sioservice/vroproxy', infoProps, apiheaders)
        .then((response) => {
          this.OPools = response.body;
          this.$root.showloader = false
        })
        .catch((response) => {
          this.$root.showloader = false
          try {
            var body = JSON.parse(response)
            alert(body.error)
            } catch (response) { 
                alert('There was an error POSTing to ' + '/api/sioservice/vroproxy' + ': ' + response.statusCode.toString())
              }
        })
      },

      handleSubmit () {
        this.$root.showloader = true
        var cO = Object.assign({}, this.currentItem);
        cO.vpTier = cO.poolTier
        var poolname = this.OPools.filter(function (obj) { 
         return cO.onlinePools.indexOf(obj.id) > -1
        });
        cO.onlinePools = []
        // [cO.onlinePools];
        for (var i = 0; i < poolname.length; i++) {
          cO.onlinePools.push(poolname[i].citiPoolName)
        }
        const infoProps = {
            'workflowSync': 'addSIOVP',
            CSIID: 'sioservice',
            'parameters': {
              vpData: JSON.stringify([cO])
              }
          }
          
      this.$http
        .post('/api/sioservice/vroproxy', infoProps, apiheaders)
        .then((response) => {
          if (response.body[0].status === 'ok') {
            this.hidemodal()
            this.getAllVirtualPools()
            alert('Access Plan created succesfully')
          } else {
            alert('Please enter valid information')
          }
          this.$root.showloader = false
        })
        .catch((response) => {
          this.$root.showloader = false
          try {
            var body = JSON.parse(response)
            alert(body.error)
            } catch (response) { 
                alert('There was an error POSTing to ' + '/api/sioservice/vroproxy' + ': ' + response.statusCode.toString())
              }
        })
      },

      startplan (vpid, set) {
        this.$root.showloader = true
        const infoProps = {
          'workflowSync': set ? 'setVPOnline' : 'setVPOffline',
      CSIID: 'sioservice',
      'parameters': {
      'vpId': vpid
          }   
      }

        this.$http
      .post('/api/sioservice/vroproxy', infoProps, apiheaders)
      .then((response) => {
        this.$root.showloader = false
        alert('The Status of the Access Plan has been updated Successfully!')
      })
      .catch((response) => {
        this.$root.showloader = false
        try {
          var body = JSON.parse(response)
          alert(body.error)
          } catch (response) { 
              alert('There was an error POSTing to ' + '/api/sioservice/vroproxy' + ': ' + response.statusCode.toString())
            }
      })
    },
      
    getAllVirtualPools () {
      this.$root.showloader = true
      const infoProps = {
        'workflowSync': 'listSIOVPs',
        CSIID: 'sioservice',
        parameters: {
          
        }
          }
          
      this.$http
        .post('/api/sioservice/vroproxy', infoProps, apiheaders)
        .then((response) => {
          this.tableData = response.body;
          this.$root.showloader = false
        })
        .catch((response) => {
          this.$root.showloader = false
          try {
            var body = JSON.parse(response)
            alert(body.error)
            } catch (response) { 
                alert('There was an error POSTing to ' + '/api/sioservice/vroproxy' + ': ' + response.statusCode.toString())
              }
        })
    }
  }
}
