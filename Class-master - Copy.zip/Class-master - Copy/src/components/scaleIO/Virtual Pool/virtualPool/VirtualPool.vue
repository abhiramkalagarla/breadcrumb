<template>
  <div class="mt-3">
    <h2 class="text-center">Access Plan</h2><br>
      <v-client-table :data="tableData" :columns="columns" :options="options">
        <div slot="afterLimit" class="pull-right">
          <button @click="newpool()" class="btn btn-success">Add</button> 
          <button @click="deletepool()" class="btn btn-danger">Delete Access Plan</button>
        </div>
        <template slot="actions" slot-scope="props">
          <b-link :to="{name:'IndvirtualPool',params:{vpID:props.row.id,vpName:props.row.vpName}}" class="btn btn-primary mr-2">Details</b-link>
     <!-- <button @click="deletepool(props.row)" class="btn btn-danger">Delete Access Plan</button>-->
        </template>
        <template slot="status (offline / online)" slot-scope="props">
          <div class="switch">
            <input v-bind:id="props.row.id" class="cmn-toggle cmn-toggle-round-flat" v-on:change=toggleplan($event,props.row)  
              v-bind:checked="props.row.vpStatus=='offline'?false:true" 
              type="checkbox">
              <label v-bind:for="props.row.id"></label>
          </div>
        </template>
      </v-client-table>

  <b-modal v-model="showModal" no-enforce-focus :hide-footer="hidefooter"  ref="myModalRef" :title="popupTitle"  @hidden="onHidden">
      <form @submit.stop.prevent="handleSubmit">

      <b-form-group id="VirtualPoolName"
                  label="Access Plan Name"
                  class="required"
                  label-for="virtualpoolnameInput">
      <b-form-input id="virtualpoolnameInput"
                    type="text"
                    v-model="currentItem.vpName"
                    :state="null"
                    aria-describedby="virtualpoolnameInputt"
                    placeholder="Enter Access Plan Name" />
      <b-form-invalid-feedback id="virtualpoolnameInput">
       This is a required field
      </b-form-invalid-feedback>
    </b-form-group>

    <b-form-group id="OfflinePools"
                  label="Data Center"
                  class="required"
                  label-for="datacenterInput">
                   <v-select taggable :options="dataCenter" v-model="currentItem.dataCenter"></v-select>
     <!-- <b-form-select id="datacenterInput"
                    :options="dataCenter"
                    v-model="currentItem.dataCenter"
                    :state="null"
                    aria-describedby="datacenterInput"
                    placeholder="Enter Data Center" /> -->
      <b-form-invalid-feedback id="datacenterInput">
       This is a required field
      </b-form-invalid-feedback>
    </b-form-group>

    <b-form-group id="PoolTier"
                  label="Pool Tier"
                  class="required"
                  label-for="pooltierInput">
      <b-form-select id="pooltierInput"
                    :options="poolTier"
                    v-model="currentItem.poolTier"
                    :state="null"
                    aria-describedby="vpTierInput"
                    placeholder="Enter Pool Tier" />
      <b-form-invalid-feedback id="pooltierInput">
       This is a required field
      </b-form-invalid-feedback>
    </b-form-group>

    <b-form-group id="OnlinePools"
                  label="Online Pools"
                  description="All Online Pools in the database are listed here"
                  class="required"
                  label-for="onlinepoolsInput">
                  <b-form-select id="poolType"
                  :options="OPools"
                  multiple
                  text-field="citiPoolName"
                  value-field="id"
                  v-model="currentItem.onlinePools" />
      <b-form-invalid-feedback id="onlinepoolsInput">
       This is a required field
      </b-form-invalid-feedback>
    </b-form-group>   

    <b-button type="submit" variant="primary" :disabled="$v.currentItem.$invalid">Submit</b-button>
    <b-button type="button" @click="hidemodal()" variant="default">Cancel</b-button>

    </form>
  </b-modal>

  <b-modal  no-enforce-focus  :hide-footer="hidefooter"  ref="myDeleteModalRef" :title="'Delete Access Plan'">
    <b-form-group id="Delete"
                  label="Please select the Access Plan to delete"
                  class="required"
                  label-for="deletevirtualpoolInput">
      <b-form-select id="deletevirtualpoolInput"
                    :options="tableData"
                       text-field="vpName"
                       value-field="id"
                    v-model="deleteVirtualPool"
                    :state="null"
                    aria-describedby="deletevirtualpoolInput"/>
      <b-form-invalid-feedback id="deletevirtualpoolInput">
       This is a required field
      </b-form-invalid-feedback>
    </b-form-group>
    <b-button type="button" variant="primary" @click="delcheck()">OK</b-button>
    <b-button type="button" @click="hidecancelmodal()" variant="default">Cancel</b-button>
  </b-modal>

  </div>
</template>

<script src="./virtualPool.js">
</script>
