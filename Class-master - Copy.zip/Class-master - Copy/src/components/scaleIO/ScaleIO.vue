<template>
  <div>
  <b-row>
  <b-col class="mt-10">
    <b-card-group deck>
        <b-card title="ScaleIO Cluster">
            <p class="card-text">
                View and manage Clusters 
            </p>
            <div slot="footer">
                <b-button to="/scaleIO/Cluster"
                      variant="primary">GO</b-button>
            </div>
        </b-card>
        <b-card title="ScaleIO Pools">
            <p class="card-text">
                View and Manage Pools
            </p>
            <div slot="footer">
                <b-button to="/scaleIO/Pools"
                      variant="primary">GO</b-button>
            </div>
        </b-card>
        <b-card title="Access Plan" v-b-popover.top.hover="text" >
            <p class="card-text">
                Access Control and Quota for Provisioning Applications (ACAs)
            </p>
            <div slot="footer">
                <b-button to="/scaleIO/VirtualPool"
                      variant="primary">GO</b-button>
            </div>
        </b-card>
        <b-card title="Access Plan Subscribers">
            <p class="card-text">
                View Pool Subscribers
            </p>
            <div slot="footer">
                <b-button to="/scaleIO/Subscribers"
                      variant="primary">GO</b-button>
            </div>
        </b-card>
    </b-card-group>
    </b-col>
    </b-row>

    <b-row>
    <b-col class="col-sm-9 mt-4">
    <b-card-group deck>
        <b-card title="SDCs">
            <p class="card-text">
                View SDCs
            </p>
            <div slot="footer">
                <b-button to="/scaleIO/SDCs"
                      variant="primary">GO</b-button>
            </div>
        </b-card>
        <b-card title="ScaleIO Host Provisioning">
            <p class="card-text">
                Manage Host Provisioning
            </p>
            <div slot="footer">
                <b-button to="/scaleIO/HostProvisioning"
                      variant="primary">GO</b-button>
            </div>
        </b-card>
        <b-card title="ScaleIO VM Subscribers">
            <p class="card-text">
                View ScaleIO VM Subscribers
            </p>
            <div slot="footer">
                <b-button to="/scaleIO/VMSubscribers" disabled
                      variant="primary">GO</b-button>
            </div>
        </b-card>
    </b-card-group>
    </b-col>
    </b-row>
    
 </div>
</template>

<script>
export default {
  name: 'ScaleIO',
  data () {
    return {
        text: 'Access Plan is a configuration element in the ScaleIO Self-Service API that restricts provisioning access to certain clusters and pools, and also limits the amount of storage that can be provisioned in each of those pools, on a per provisioning application (ACA) basis'
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.mt-10{
  margin-top:10px;
}
</style>
