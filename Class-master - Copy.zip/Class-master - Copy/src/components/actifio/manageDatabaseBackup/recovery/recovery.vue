<template>
  <div class="mt-2">
    <b-row>
        <b-col md="8">
          <h2 class="text-center">Select Backups Image for Recovery</h2><br>
          <v-client-table :data="recoveryData" :columns="recoverycolumns" :options="recoveryoptions">
            <template slot="select" slot-scope="props">
            <input type="radio" v-model="logRecoveryradio" name="logrecovery" :value="props.row.imageName">
            </template>
          </v-client-table>
        </b-col>
    </b-row>

    <b-button variant="primary" class="mb-3" @click="getLogRecoveryRange()">List available Log recovery range</b-button>
    <b-row>
        <b-col md="8">

          <v-client-table :data="recoverylogData" :columns="recoverylogcolumns" :options="recoverylogoptions">
          </v-client-table>
        </b-col>
    </b-row>

    <b-row>
        <b-col sm="3"><label for="input-default">Enter the time for log roll forward:</label></b-col>
          <b-col sm="4">
            <vue-ctk-date-time-picker v-model="Datetime" formatted= 'YYYY-MM-DD HH:mm:SS'> </vue-ctk-date-time-picker>
          </b-col>
    </b-row>

    <b-form-group label="Choose the recovery Options">
      <b-form-radio-group v-model="selected"
                          :options="options"
                          stacked
                          name="radiosStacked">
      </b-form-radio-group>
    </b-form-group>

<div class="row" v-if="selected=='First'">
<div class="col-md-8">
      <b-form-group id="firstRecovery"
                  label="Please select the Database for Recovery"
                  class="required"
                  horizontal
                  :label-cols="4"
                  label-for="firstRecoveryInput">
                  <b-form-select id="firstRecovery"
                  :options="database"
                  multiple
                  v-model="firstRecovery" />
      <b-form-invalid-feedback id="firstRecoveryInput">
       This is a required field
      </b-form-invalid-feedback>
    </b-form-group>   

      <b-form-group id="recoveryTarget"
                    label="Target"
                    horizontal
                    :label-cols="4"
                    breakpoint="md"
                    label-for="targetInput">
      <b-form-input id="targetInput"
                    type="text"
                    v-model.lazy="recoveryTable.targetHost"
                    aria-describedby="targetInput"
                    placeholder="Target" />
    </b-form-group>
    <b-form-group id="recoveryconsistentGroup"
                    label="Name Of Consistency Group"
                    horizontal
                    :label-cols="4"
                    breakpoint="md"
                    label-for="groupInput">
      <b-form-input id="groupInput"
                    type="text"
                    v-model="recoveryTable.consistentgroup"
                    aria-describedby="groupInput"
                    placeholder="Name Of Consistency Group" />
    </b-form-group>
    <b-form-group id="recoveryTable"
                    label="SQL Server Instance Name"
                    horizontal
                    :label-cols="4"
                    breakpoint="md"
                    label-for="instanceNameInput">
      <b-form-input id="instanceNameInput"
                    type="text"
                    v-model="recoveryTable.instanceName"
                    aria-describedby="instanceNameInput"
                    placeholder="SQL Server Instance Name" />
    </b-form-group>
    <b-form-group id="recoveryTable"
                    label="Prefix for SQL Server Database Name"
                    horizontal
                    :label-cols="4"
                    breakpoint="md"
                    label-for="databaseNameInput">
      <b-form-input id="databaseNameInput"
                    type="text"
                    v-model="recoveryTable.dbnameprefix"
                    aria-describedby="databaseNameInput"
                    placeholder="Prefix for SQL Server Database Name" />
    </b-form-group>
    <b-form-group id="recoveryTable"
                    label="UserName"
                    horizontal
                    :label-cols="4"
                    breakpoint="md"
                    label-for="usernameInput">
      <b-form-input id="usernameInput"
                    type="text"
                    v-model="recoveryTable.username"
                    aria-describedby="usernameInput"
                    placeholder="UserName" />
    </b-form-group>
    <b-form-group id="recoveryTable"
                    label="Password"
                    horizontal
                    :label-cols="4"
                    breakpoint="md"
                    label-for="passwordInput">
      <b-form-input id="passwordInput"
                    type="text"
                    v-model="recoveryTable.password"
                    aria-describedby="passwordInput"
                    placeholder="Password" />
    </b-form-group>
    <b-button type="submit" variant="primary"  @click="submitrecovery()">Submit</b-button>
</div>
</div>

<div class="row" v-if="selected=='Second' || selected=='Fourth'">
<div class="col-md-8">
      <b-form-group id="secondRecovery"
                  label="Please select from the dropdown"
                  class="required"
                  horizontal
                  :label-cols="4"
                  label-for="secondRecoveryInput">
                  <b-form-select id="secondRecoveryInput"
                  :options="server"
                  v-model="secondRecovery" />
      <b-form-invalid-feedback id="secondRecoveryInput">
       This is a required field
      </b-form-invalid-feedback>
    </b-form-group>   
    <b-button type="submit" variant="primary"  @click="submitrecovery()">Submit</b-button>
</div>
</div>

<div class="row" v-if="selected=='Third' || selected=='Fifth'">
<div class="col-md-8">
      <b-form-group id="thirdRecovery"
                    label="Target Database SID"
                    horizontal
                    :label-cols="4"
                    breakpoint="md"
                    label-for="targetDatabseInput">
      <b-form-input id="targetDatabseInput"
                    type="text"
                    v-model="thirdItem.targetDatabse"
                    aria-describedby="targetDatabseInput"
                    placeholder="Target Database SID" />
    </b-form-group>
    <b-form-group id="thirdRecovery"
                    label="User Name"
                    horizontal
                    :label-cols="4"
                    breakpoint="md"
                    label-for="userNameInput">
      <b-form-input id="userNameInput"
                    type="text"
                    v-model="thirdItem.userName"
                    aria-describedby="userNameInput"
                    placeholder="User Name" />
    </b-form-group>
    <b-form-group id="thirdRecovery"
                    label="Password"
                    horizontal
                    :label-cols="4"
                    breakpoint="md"
                    label-for="passwordInput">
      <b-form-input id="passwordInput"
                    type="text"
                    v-model="thirdItem.password"
                    aria-describedby="passwordInput"
                    placeholder="Password" />
    </b-form-group>
    <b-form-group id="thirdRecovery"
                    label="Oracle Home Directory"
                    horizontal
                    :label-cols="4"
                    breakpoint="md"
                    label-for="homeDirectoryInput">
      <b-form-input id="homeDirectoryInput"
                    type="text"
                    v-model="thirdItem.homeDirectory"
                    aria-describedby="homeDirectoryInput"
                    placeholder="Oracle Home Directory" />
    </b-form-group>
    <b-form-group id="thirdRecovery"
                    label="TNS ADMIN Admin Directory path"
                    horizontal
                    :label-cols="4"
                    breakpoint="md"
                    label-for="adminDirectoryInput">
      <b-form-input id="adminDirectoryInput"
                    type="text"
                    v-model="thirdItem.adminDirectory"
                    aria-describedby="adminDirectoryInput"
                    placeholder="TNS ADMIN Directory path" />
    </b-form-group>
    <b-form-group id="thirdRecovery"
                    label="Database Memory Size(MB)"
                    horizontal
                    :label-cols="4"
                    breakpoint="md"
                    label-for="memorySizeInput">
      <b-form-input id="memorySizeInput"
                    type="text"
                    v-model="thirdItem.memorySize"
                    aria-describedby="memorySizeInput"
                    placeholder="Database Memory Size(MB)" />
    </b-form-group>
    <b-form-group id="thirdRecovery"
                    label="SGA %"
                    horizontal
                    :label-cols="4"
                    breakpoint="md"
                    label-for="sgaInput">
      <b-form-input id="sgaInput"
                    type="text"
                    v-model="thirdItem.sga"
                    aria-describedby="sgaInput"
                    placeholder="SGA %" />
    </b-form-group>
    <b-form-group id="thirdRecovery"
                    label="REDO Size"
                    horizontal
                    :label-cols="4"
                    breakpoint="md"
                    label-for="redoSizeInput">
      <b-form-input id="redoSizeInput"
                    type="text"
                    v-model="thirdItem.redoSize"
                    aria-describedby="redoSizeInput"
                    placeholder="REDO Size" />
    </b-form-group>
    <b-form-group id="thirdRecovery"
                    label="Shared_Pool_Size(MB)"
                    horizontal
                    :label-cols="4"
                    breakpoint="md"
                    label-for="sharedPoolSizeInput">
      <b-form-input id="sharedPoolSizeInput"
                    type="text"
                    v-model="thirdItem.sharedPoolSize"
                    aria-describedby="sharePoolSizeInput"
                    placeholder="Shared_Pool_Size(MB)" />
    </b-form-group>
    <b-form-group id="thirdRecovery"
                    label="db_Cache_Size(MB)"
                    horizontal
                    :label-cols="4"
                    breakpoint="md"
                    label-for="dbCacheSizeInput">
      <b-form-input id="dbCacheSizeInput"
                    type="text"
                    v-model="thirdItem.dbCacheSize"
                    aria-describedby="dbCacheSizeInput"
                    placeholder="db_Cache_Size(MB)" />
    </b-form-group>
    <b-form-group id="thirdRecovery"
                    label="db_recovery_file_dest_size(MB)"
                    horizontal
                    :label-cols="4"
                    breakpoint="md"
                    label-for="recoveryFileSizeInput">
      <b-form-input id="recoveryFileSizeInput"
                    type="text"
                    v-model="thirdItem.recoveryFileSize"
                    aria-describedby="recoveryFileSizeInput"
                    placeholder="db_recovery_file_dest_size(MB)" />
    </b-form-group>
    <b-form-group id="thirdRecovery"
                    label="diagnostic_dest"
                    horizontal
                    :label-cols="4"
                    breakpoint="md"
                    label-for="diagnosticDestInput">
      <b-form-input id="diagnosticDestInput"
                    type="text"
                    v-model="thirdItem.diagnosticDest"
                    aria-describedby="diagnosticDestInput"
                    placeholder="diagnostic_dest" />
    </b-form-group>
    <b-form-group id="thirdRecovery"
                    label="Max Number of Processes"
                    horizontal
                    :label-cols="4"
                    breakpoint="md"
                    label-for="maxNumOfProcessesInput">
      <b-form-input id="maxNumOfProcessesInput"
                    type="text"
                    v-model="thirdItem.maxNumOfProcesses"
                    aria-describedby="maxNumOfProcessesInput"
                    placeholder="Max Number of Processes" />
    </b-form-group>
    <b-form-group id="thirdRecovery"
                    label="Max Number of Open Cursors"
                    horizontal
                    :label-cols="4"
                    breakpoint="md"
                    label-for="maxNumOfCursorsInput">
      <b-form-input id="maxNumOfCursorsInput"
                    type="text"
                    v-model="thirdItem.maxNumOfCursors"
                    aria-describedby="maxNumOfCursorsInput"
                    placeholder="Max Number of Open Cursors" />
    </b-form-group>
    <b-form-group id="thirdRecovery"
                    label="Character Set"
                    horizontal
                    :label-cols="4"
                    breakpoint="md"
                    label-for="characterSetInput">
      <b-form-input id="characterSetInput"
                    type="text"
                    v-model="thirdItem.characterSet"
                    aria-describedby="characterSetInput"
                    placeholder="Character Set" />
    </b-form-group>
    <b-form-group id="thirdRecovery"
                    label="TNS Listener IP"
                    horizontal
                    :label-cols="4"
                    breakpoint="md"
                    label-for="listenerIPInput">
      <b-form-input id="listenerIPInput"
                    type="text"
                    v-model="thirdItem.listenerIP"
                    aria-describedby="listenerIPInput"
                    placeholder="TNS Listener IP" />
    </b-form-group>
    <b-form-group id="thirdRecovery"
                    label="TNS Listener Port"
                    horizontal
                    :label-cols="4"
                    breakpoint="md"
                    label-for="listenerPortInput">
      <b-form-input id="targetDatabse"
                    type="text"
                    v-model="thirdItem.listenerPort"
                    aria-describedby="listenerPortInput"
                    placeholder="TNS Listener Port" />
    </b-form-group>
    <b-form-group id="thirdRecovery"
                    label="TNS Domain Name"
                    horizontal
                    :label-cols="4"
                    breakpoint="md"
                    label-for="domainNameInput">
      <b-form-input id="domainNameInput"
                    type="text"
                    v-model="thirdItem.domainName"
                    aria-describedby="domainNameInput"
                    placeholder="TNS Domain Name" />
    </b-form-group>
    <b-form-group id="thirdRecovery"
                    label="Restore with Recovery"
                    horizontal
                    :label-cols="4"
                    breakpoint="md"
                    label-for="restoreRecoveryInput">
      <b-form-input id="restoreRecoveryInput"
                    type="text"
                    v-model="thirdItem.restoreRecovery"
                    aria-describedby="restoreRecoveryInput"
                    placeholder="Restore with Recovery" />
    </b-form-group>
  <b-button type="submit" variant="primary"  @click="submitrecovery()">Submit</b-button>
</div>
</div>

<div class="row" v-if="selected=='Sixth'">
<div class="col-md-8">
      <b-form-group id="SixthRecovery"
                  label="Enter ASM diskgroup name for Recovery"
                  class="required"
                  horizontal
                  :label-cols="4"
                  breakpoint="md"
                  label-for="diskgroupname">
                  <b-input-group>
    <b-form-input id="diskgroupname"
                    type="text"
                    v-model="sixthItem.diskgroupName"
                    aria-describedby="diskgroupname"
                    placeholder="Enter ASM diskgroup name for Recovery" />
                    <b-input-group-append>
                    <b-btn variant="primary" @click="getValidation()">Validate</b-btn>
                    </b-input-group-append>
                    </b-input-group>
    </b-form-group>

    <b-form-group id="SixthRecovery"
                  label="Validation Status"
                  class="required"
                  horizontal
                  :label-cols="4"
                  breakpoint="md"
                  label-for="validationstatus">
                  <b-input-group>
    <b-form-input id="validationstatus"
                    type="text"
                    v-model="sixthItem.validationStatus"
                    aria-describedby="validationstatus"
                    placeholder="Validation Status" />
                    <b-input-group-append>
                    <b-btn variant="primary" @click="getValidationStatus()">Submit</b-btn>
                    </b-input-group-append>
                    </b-input-group>
    </b-form-group>
</div>
</div>

  </div>
</template>

<script src="./recovery.js">
</script>
