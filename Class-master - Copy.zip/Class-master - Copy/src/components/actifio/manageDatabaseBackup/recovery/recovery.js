import { validationMixin } from 'vuelidate'
import { required } from 'vuelidate/lib/validators'

const apiheaders = {
  headers: {
    'Content-Type': 'application/json',
    Accept: 'application/json'
}
}
export default {
  name: 'recovery',
  watch: {
    selected: function (newValue, oldvalue) {
      if (newValue == 'First') {
        this.getTargetHosts();
        this.getSqlDBNames();
      }  
  }
  },
  data () {
    return {
         recoverycolumns: ['select', 'imageName', 'backupDate'],
         recoverylogcolumns: ['logStartTime', 'logEndTime'],
         recoveryData: [],
         recoverylogData: [],
         logRecoveryradio: '',
         database: [],
         Server: [],
         firstRecovery: {},
         recoveryTable: {},
         secondRecovery: {},
         thirdItem: {},
         sixthItem: {},
         Datetime: '',
         recoveryoptions: {
            templates: {},
            headings: {
                select: 'Select',
                imageName: 'ImageName',
                backupDate: 'BackupDate'
              },
            text: {
                filter: 'Search  Virtual pools:',
                filterPlaceholder: 'Virtual pools...',
                limit: 'Entries per Page: '

            },
            filterable: false,
            perPage: 10,
            pagination: { chunk: 10, dropdown: false }
            // see the options API
          },
          recoverylogoptions: {
            templates: {},
            headings: {
                  logStartTime: 'Log Start Time',
                  logEndTime: 'Log End Time'
              },
            text: {
                  filter: 'Search  Virtual pools:',
                  filterPlaceholder: 'Virtual pools...',
                  limit: 'Entries per Page: '
  
              },
            filterable: false,
            perPage: 10,
            pagination: { chunk: 10, dropdown: false }
              // see the options API
          },
          selected: '',
          options: [
            { text: 'SQL Partial Recovery(Windows)', value: 'First' },
            { text: 'SQL Full Recovery(Windows)', value: 'Second' },
            { text: 'Oracle on  Filesystem Partial Recovery(Unix)', value: 'Third' },
            { text: 'Oracle on  Filesystem Full Recovery(Unix)', value: 'Fourth' },
            { text: 'Oracle on  ASM Partial Recovery(Unix)', value: 'Fifth' },
            { text: 'Oracle on  ASM Full Recovery(Unix)', value: 'Sixth' }
          ]
        }
      },
      mixins: [validationMixin],
    validations: {
      firstRecovery: {
        firstRecovery: {
          required
        }
      },
      recoveryTable: {
        targetHost: {
          required
        },
        consistentgroup: {
          required
        },
        instanceName: {
          required
        },
        dbnameprefix: {
          required
        },
        username: {
          required
        },
        password: {
          required
        }
      },
      secondRecovery: {
        secondRecovery: {
            required
          }
        },
      thirdItem: {
        targetDatabse: {
              required
            },
        userName: {
              required
            },
        password: {
              required
            },
        homeDirectory: {
              required
            },
        adminDirectory: {
              required
            },
        memorySize: {
              required
            },
        sga: {
              required
            },
        redoSize: {
              required
            },
        sharedPoolSize: {
              required
            },
        dbCacheSize: {
              required
            },
        recoveryFileSize: {
              required
            },
        diagnosticDest: {
              required
            },
        maxNumOfProcesses: {
              required
            },
        maxNumOfCursors: {
              required
            },
        characterSet: {
              required
            },
        listenerIP: {
              required
            },
        domainName: {
              required
            },
        restoreRecovery: {
              required
            }
          },
      fifthItem: {
        targetDatabse: {
            required
              },
              userName: {
                required
              },
              password: {
                required
              },
              homeDirectory: {
                required
              },
              adminDirectory: {
                required
              },
              memorySize: {
                required
              },
              sga: {
                required
              },
              redoSize: {
                required
              },
              sharedPoolSize: {
                required
              },
              dbCacheSize: {
                required
              },
              recoveryFileSize: {
                required
              },
              diagnosticDest: {
                required
              },
              maxNumOfProcesses: {
                required
              },
              maxNumOfCursors: {
                required
              },
              characterSet: {
                required
              },
              listenerIP: {
                required
              },
              domainName: {
                required
              },
              restoreRecovery: {
                required
              }
            },
          SixthItem: {
              diskgroupName: {
                  required
                },
                validationStatus: {
                  required
                }
          }
  },
  created () {
   this.getBackupImages();
  },
  methods: {
    getBackupImages () {
      const infoProps = {
        CSIID: this.$parent.dashboard.CSIID,
        action: 'com.citi.cloud.actifio.storageautomation/getBackupImages',
        parameters: {
          csiID: this.$parent.dashboard.CSIID,
          serverName: this.$parent.dashboard.serverNames,
          appName: this.$parent.dashboard.appName
        }
      };
      this.$http
        .post('/api/dps/vroproxy', infoProps, apiheaders)
        .then(response => {
          this.recoveryData = response.body.result;
        })
        .catch(response => {
          console.log(response);
        });
    },

    getLogRecoveryRange () {
      const infoProps = {
       CSIID: this.$parent.dashboard.CSIID,
        action: 'com.citi.cloud.actifio.storageautomation/getLogRecoveryRange',
        parameters: {
          csiID: this.$parent.dashboard.CSIID,
          serverName: this.$parent.dashboard.serverNames,
          appName: this.$parent.dashboard.appName,
          imageName: this.logRecoveryradio
        }
      };
      this.$http
        .post('/api/dps/vroproxy', infoProps, apiheaders)
        .then(response => {
          this.recoverylogData = [response.body.result];
        })
        .catch(response => {
          console.log(response);
        });
    },

    getTargetHosts () {
      const infoProps = {
       CSIID: this.$parent.dashboard.CSIID,
        action: 'com.citi.cloud.actifio.storageautomation/getTargetHosts',
        parameters: {
          csiID: this.$parent.dashboard.CSIID,
          serverName: this.$parent.dashboard.serverNames,
          appName: this.$parent.dashboard.appName
        }
      };
      this.$http
        .post('/api/dps/vroproxy', infoProps, apiheaders)
        .then(response => {
          this.$set(this.recoveryTable, 'targetHost', response.body.result[0].hostName)
          // this.recoveryTable.targetHost = response.body.result[0].hostName;
        })
        .catch(response => {
          console.log(response);
        });
    },

    getSqlDBNames () {
      const infoProps = {
       CSIID: this.$parent.dashboard.CSIID,
        action: 'com.citi.cloud.actifio.storageautomation/getSqlDBNames',
        parameters: {
          csiID: this.$parent.dashboard.CSIID,
          serverName: this.$parent.dashboard.serverNames,
          instanceName: this.$parent.dashboard.appName
        }
      };
      this.$http
        .post('/api/dps/vroproxy', infoProps, apiheaders)
        .then(response => {
          this.database = response.body.result;
        })
        .catch(response => {
          console.log(response);
        });
    },

    dpsRecovery () {
      const infoProps = {
       CSIID: this.$parent.dashboard.CSIID,
       workflowAsync: 'dpsRecovery',
        parameters: {
          csiID: this.$parent.dashboard.CSIID,
          appName: this.$parent.dashboard.appName,
          serverName: this.$parent.dashboard.serverNames,
          targetHost: this.recoveryTable.targetHost,
          options: {
                recoveryType: '',
                sqlinstance: '',
                dbname: '',
                username: '',
                password: '',
                logForwardingTime: '',
                appNames: ''
            }
        }
      };
      this.$http
        .post('/api/dps/vroproxy', infoProps, apiheaders)
        .then(response => {
          this.database = response.body.result;
        })
        .catch(response => {
          console.log(response);
        });
    }
  }
}
