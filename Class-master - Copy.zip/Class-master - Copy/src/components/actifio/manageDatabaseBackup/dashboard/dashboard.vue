<template>
  <div class="mt-2">
  <b-row>
  <b-col md="8">
  <h2 class="text-center">Manage Backup(DBA)</h2><br>
    <b-form-group id="Group1"
                  label="CSI Application ID"
                  class="required"
                  horizontal
                  :label-cols="4"
                  breakpoint="md"
                  label-for="appID">
                  <b-input-group>
    <b-form-input id="appID"
                    type="text"
                    v-model="dashboard.CSIID"
                    aria-describedby="appID"
                    placeholder="Enter CSI App ID" />
                    <b-input-group-append>
                    <b-btn variant="primary" @click="getAppInfo()">Get Server Info</b-btn>
                    </b-input-group-append>
                    </b-input-group>
      <span class="invalid-feedback d-block" v-if="isValidCSIID">The Entered CSIID is invalid. Please try again...</span>
    </b-form-group>

    <b-form-group id="OfflinePools"
                  class="required"
                  label="Select the Database Server Names:"
                  horizontal
                  :label-cols="4"
                  breakpoint="md"
                  label-for="serverNames">
                  <b-input-group>
    <b-form-select id="serverNames"
                 :options="serverNames"
                  v-model="dashboard.serverNames"
                  aria-describedby="serverNames"
                  placeholder="Select Server Name" />
                    <b-input-group-append>
                    <b-btn variant="primary" @click="getAppDetails()">Get Database Info</b-btn>
                    </b-input-group-append>
                    </b-input-group>
    </b-form-group>

    <b-form-group id="OfflinePools"
                    class="required"
                    label="Select the Database"
                    horizontal
                    :label-cols="4"
                    breakpoint="md"
                    label-for="appName">
                    <b-input-group>
    <b-form-select id="database"
                    :options="appName"
                    text-field="appName"
                    value-field="appName"
                    v-model="dashboard.appName"
                    aria-describedby="database"
                    placeholder="Select the Database"/>
                    <b-input-group-append>
                    <b-btn variant="primary" @click="getOracleDetails()">Lookup</b-btn>
                    </b-input-group-append>
                    </b-input-group>
    </b-form-group>
    
</b-col>
</b-row>
<br><br>
<b-button @click="setActiveGroup('CM')" variant="primary" class="mr-4">Check Current Mounts</b-button>
<b-button @click="setActiveGroup('MAS')" variant="primary" class="mr-4">Manage Advanced Settings</b-button>
<b-button @click="setActiveGroup('EDB')" variant="primary" class="mr-4">Resume/Pause Backup</b-button>
<b-button @click="setActiveGroup('R')" variant="primary" class="mr-4">Recovery</b-button> 
<b-button @click="setActiveGroup('RBP')" variant="primary" class="mr-4">Disable Backup protection</b-button>

<recovery v-if="showchild==='R'"></recovery>
<checkCurrentMounts v-if="showchild==='CM'"></checkCurrentMounts>
<manageAdvancedSettings v-if="showchild==='MAS'"></manageAdvancedSettings>
<removeBackupProtection v-if="showchild==='RBP'"></removeBackupProtection>
<toggleBackup v-if="showchild==='EDB'"></toggleBackup>

</div>
</template>

<script src = "./dashboard.js">

</script>
