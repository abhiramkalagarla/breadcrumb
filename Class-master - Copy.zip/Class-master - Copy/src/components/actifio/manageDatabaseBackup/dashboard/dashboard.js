import { validationMixin } from 'vuelidate';
import { required } from 'vuelidate/lib/validators';
import recovery from '../recovery/recovery.vue';
import checkCurrentMounts from '../checkCurrentMounts/checkCurrentMounts.vue'
import removeBackupProtection from '../removeBackupProtection/removeBackupProtection.vue'
import manageAdvancedSettings from '../manageAdvancedSettings/manageAdvancedSettings.vue'
import toggleBackup from '../toggleBackup/toggleBackup.vue'
const apiheaders = {
    headers: {
      'Content-Type': 'application/json',
      Accept: 'application/json'
}
}
export default {
  name: 'dashboard',
  components: { recovery, checkCurrentMounts, toggleBackup, removeBackupProtection, manageAdvancedSettings },
  data () {
    return {
      serverName: [],
      isValidCSIID: false,
      database: [],
      serverNames: [],
      appName: [],
      dashboard: {},
      showchild: '',
      actinfolookup: {},
      template: 'default'
    };
  },
  mixins: [validationMixin],
  validations: {
    dashboard: {
      CSIID: {
        required
      },
      serverNames: {
        required
      },
      appName: {
        required
      }
    }
  },
  methods: {
    setActiveGroup (value) {
      this.showchild = value
    },
    getAppInfo () {
      const infoProps = {
        CSIID: this.dashboard.CSIID,
        action: 'com.citi.cloud.actifio.storageautomation/getBackupEnabledServers',
        parameters: {
            csiID: this.dashboard.CSIID
          }        
      }
      this.$http
        .post('/api/dps/vroproxy', infoProps, apiheaders)
        .then(response => {
          this.serverNames = response.body.result;
        })
        .catch(response => {
          console.log(response);
        });
    },
    getAppDetails () {
      const infoProps = {
        CSIID: this.dashboard.CSIID,
        action: 'com.citi.cloud.actifio.storageautomation/getBackupApplications',
        parameters: {
            csiID: this.dashboard.CSIID,
            serverNames: this.dashboard.serverNames
          }
      }
      this.$http
      .post('/api/dps/vroproxy', infoProps, apiheaders)
      .then(response => {
          this.appName = response.body.result;
        })
        .catch(response => {
          console.log(response);
        });
    },
    getOracleDetails () {
      const infoProps = {
        CSIID: this.dashboard.CSIID,
        action: 'com.citi.cloud.actifio.storageautomation/getOracleDetailsFromHost',
        parameters: {
            csiID: this.dashboard.CSIID,
            serverNames: this.dashboard.serverNames,
            appName: this.dashboard.appName
          }
      }
      this.$http
      .post('/api/dps/vroproxy', infoProps, apiheaders)
      .then(response => {
          this.appName = response.body.result;
        })
        .catch(response => {
          console.log(response);
        });
    }

  }
}
