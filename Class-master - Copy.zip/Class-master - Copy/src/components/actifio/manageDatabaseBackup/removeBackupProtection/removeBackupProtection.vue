<template>
  <div class="mt-2">
    <b-row>
        <b-col md="8">
            <h2 class="text-center">Disable Backup Protection</h2><br>
        </b-col>
    </b-row>
  </div>
</template>

<script>
import { validationMixin } from 'vuelidate'
import { required } from 'vuelidate/lib/validators'
export default {
  name: 'recovery',
  data () {
    return {
    }
  }
}
</script>
