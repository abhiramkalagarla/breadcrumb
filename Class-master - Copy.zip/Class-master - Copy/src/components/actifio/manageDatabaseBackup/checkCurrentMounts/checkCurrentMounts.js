import { validationMixin } from 'vuelidate';
import { required } from 'vuelidate/lib/validators';
const apiheaders = {
  headers: {
    'Content-Type': 'application/json',
     Accept: 'application/json'
}
}
export default {
  name: 'checkCurrentMounts',
  data () {
    return {
      checkCurrentMountscolumns: [
        'select',
        'appType',
        'imageName',
        'backupDate'
      ],
      checkCurrentMountsData: [],
      removeradio: '',
      checkCurrentMountsoptions: {
        templates: {},
        text: {
          filter: 'Search  Virtual pools:',
          filterPlaceholder: 'Virtual pools...',
          limit: 'Entries per Page: ' 
        },
        filterable: false,
        perPage: 10,
        pagination: { chunk: 10, dropdown: false }
        // see the options API
      }
    };
  },
  created () {
   this.getCurrentMounts();
  },
  methods: {
    getCurrentMounts () {
      const infoProps = {
        CSIID: this.$parent.dashboard.CSIID,
        action: 'com.citi.cloud.actifio.storageautomation/getCurrentMounts',
        parameters: {
          csiID: this.$parent.dashboard.CSIID,
          serverName: this.$parent.dashboard.serverNames,
          appName: this.$parent.dashboard.appName
        }
      };
      this.$http
        .post('/api/dps/vroproxy', infoProps, apiheaders)
        .then(response => {
          this.checkCurrentMountsData = response.body.result;
        })
        .catch(response => {
          console.log(response);
        });
    },

    getDeleteImage () {
      const infoProps = {
        CSIID: this.$parent.dashboard.CSIID,
        'workflowSync': 'dpsDeleteImage',
        parameters: {
          csiID: this.$parent.dashboard.CSIID,
          appName: this.$parent.dashboard.appName,
          serverName: this.$parent.dashboard.serverNames,
          imageName: this.removeradio
              }
          }
      this.$http
        .post('/api/dps/vroproxy', infoProps, apiheaders)
        .then(response => {
          this.checkCurrentMountsData = response.body.result;
        })
        .catch(response => {
          console.log(response);
        });
    }
  }
}
