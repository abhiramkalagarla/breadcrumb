<template>
  <div class="mt-2">
    <b-row>
        <b-col md="8">
          <h2 class="text-center">Check Current Mounts</h2><br>
          <v-client-table :data="checkCurrentMountsData" :columns="checkCurrentMountscolumns" :options="checkCurrentMountsoptions">
            <template slot="select" slot-scope="props">
              <input type="radio" v-model="removeradio" name="removeattached" :value="props.row.imageName">
            </template>
          </v-client-table>
        </b-col>
    </b-row>
    <b-button variant="primary" @click="getDeleteImage()">Remove attached Image</b-button>
  </div>
</template>

<script src="./checkCurrentMounts.js">
</script>
