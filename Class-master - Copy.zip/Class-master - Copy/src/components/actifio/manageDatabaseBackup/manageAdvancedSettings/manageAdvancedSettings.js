import { validationMixin } from 'vuelidate';
import { required } from 'vuelidate/lib/validators';
const apiheaders = {
  headers: {
    'Content-Type': 'application/json',
     Accept: 'application/json'
}
}
export default {
  name: 'manageAdvancedSettings',
  data () {
    return {
      manageAdvancedSettingscolumns: ['select', 'name', 'currentValue', 'newValue'],
      manageAdvancedSettingsData: [],
      manageAdvancedSettingsoptions: {
        templates: {},
        headings: {
          name: 'Settings',
          currentValue: 'Current Value',
          newValue: 'New Value'
        },
        text: {
          filter: 'Search  Virtual pools:',
          filterPlaceholder: 'Virtual pools...',
          limit: 'Entries per Page: ' 
        },
        filterable: false,
        perPage: 10,
        pagination: { chunk: 10, dropdown: false }
        // see the options API
      }
    };
  },
  created () {
    this.getmanageAdvancedSettings();
  },
  methods: {
    getmanageAdvancedSettings () {
      const infoProps = {
        CSIID: this.$parent.dashboard.CSIID,
        action: 'com.citi.cloud.actifio.storageautomation/getAdvancedSettings',
        parameters: {
          csiID: this.$parent.dashboard.CSIID,
          serverName: this.$parent.dashboard.serverNames,
          appName: this.$parent.dashboard.appName
        }
      };
      this.$http
        .post('/api/dps/vroproxy', infoProps, apiheaders)
        .then(response => {
          this.manageAdvancedSettingsData = response.body.result;
        })
        .catch(response => {
          console.log(response);
        });
    }
  }
};
