<template>
  <div class="mt-2">
    <b-row>
        <b-col md="8">
          <h2 class="text-center">ManageAdvancedSettings</h2><br>
          <v-client-table :data="manageAdvancedSettingsData" :columns="manageAdvancedSettingscolumns" :options="manageAdvancedSettingsoptions">
          <template slot="select" slot-scope="props">
              <input type="checkbox" name="manageselected" :value="props.row.id">
            </template>
          </v-client-table>
        </b-col>
    </b-row>
    <b-button variant="primary">Update Settings</b-button>
  </div>
</template>

<script src="./manageAdvancedSettings.js">
</script>
