import { validationMixin } from 'vuelidate'
import { required } from 'vuelidate/lib/validators'
import mssqlTable from '../mssqlTable/mssqlTable.vue'
import oracle from '../oracle/oracle.vue'
export default {
  name: 'Dashboard',
  components: { mssqlTable, oracle },
  data () {
    return {
         billingId: [],
         groupDl: [],
         isValidCSIID: false, 
         showMsSqlTable: false,
         disableform: true,
         issubmitted: false,
         showOracleTable: false,
         purpose: ['Choose...', 'Appendix J', 'Non - ORAAS', 'VM Backup'],
         database: [{ value: null, text: 'Please select Database' }, 'MSSQL', 'Oracle'],
         actifio: {},
         actinfolookup: {},
         template: 'default'
    }
  },
  mixins: [validationMixin],
  validations: {
    actifio: {
      CSIID: {
        required
      },
      billingID: {
        required
      },
      authorizedADGroup: {
        required
      },
      purpose: {
        required
      },
      database: {
        required
      }
    }
  },
  created () {
    // this.getAppInfo();
    this.getusergroups()
  },
  watch: {
  'actifio.CSIID': function (val, oldVal) {
  this.billingId = []
    }
  },
  methods: {
    onStep1Update (newData) {
    this.issubmitted = false
    this.disableform = newData.isValid
    this.actifio.serverDetails = newData.serverDetails
      },
    onSubmitform (e) {
      e.preventDefault()
      this.postSubmitOrder()
      },
    onSubmit (e) {
      e.preventDefault()
      this.getappInfo()
    },
    getAppInfo () {
      const apiheaders = {
        headers: {
          'Content-Type': 'application/json'      
        }
      }          
      this.$http
        .get('/api/apps?CSIID=' + this.actifio.CSIID, {}, apiheaders)
        .then((response) => {
         this.billingId = response.body.billingIDs
         if (response.body.billingIDs.length == 1) {
           this.actifio.billingID = response.body.billingIDs[0]
         } else {
          alert('Billing ID found, Please select below')
         }
         this.isValidCSIID = false;
        })
        .catch((response) => {
          this.isValidCSIID = true;
          // this.$toasted.show('The Entered CSIID is invalid. Please try again...', {type: 'error', duration: 5000})
          console.log(response)
        })
    },
    getemailDL (data) {
      var c = []
      for (var i = 0; i < data.length; i++) {
        if (data[i].split(',')[1].split('=')[1] === 'Dist_Grps' || data[i].split(',')[1].split('=')[1] === 'Dist_Groups') {
        c.push({value: data[i], text: data[i].split(',')[0].split('=')[1]})
            }
      }
      this.groupDl = c;
    },
    getusergroups () {
      this.$root.showloader = true
      const apiheaders = {
        headers: {
          'Content-Type': 'application/json'      
  }
}          
      this.$http
        .get('/api/user/groups', apiheaders)
        .then((response) => {
          this.getemailDL(response.body)
         this.$root.showloader = false
        })
        .catch((response) => {
          this.$root.showloader = false
          console.log(response)
        })
    },
    postSubmitOrder () {
      this.issubmitted = true
      const apiheaders = {
        headers: {
          'Content-Type': 'application/json'      
  }
}          
      this.$http
        .post('/api/dps/create', this.actifio, apiheaders)
        .then((response) => {
          this.actifio.database = 'Please select Database'
         alert('Order Submitted Successfully!')
        })
        .catch((response) => {
          this.issubmitted = false
          console.log(response)
          alert('Order not Submitted Correctly!')
        })
  }
}
}
