/* global _ */
import { validationMixin } from 'vuelidate'
import { required, requiredUnless, requiredIf, numeric, maxValue } from 'vuelidate/lib/validators'
export default {
  name: 'oracle',
  data () {
    return {
         showModal_oracle: false,
         popupTitle_oracle: 'New DB Server',
         theme: 'bootstrap4',
         actifio: {},
         form_oracle: {},
         isServerAssociated: false,
         isserverNameValid: false,
         isGuardVisible: false,
         hidefooter: true,
         template: 'default',
         dbChangeRate: [3, 5],
         dbNames: [],
         clusteroptions: [],
         showclustererror: false,
         type: ['Choose...', 'Filesystem Standalone', 'ASM Standalone', 'Filesystem Cluster', 'ASM Clustered', 'RAC on ASM'],
         osversion: ['Linux', 'AIX'],
         oraclecolumns: ['serverName', 'type', 'os', 'dbNames', 'priDbName', 'dbSize', 'dbChangeRate', 'dbLogSize', 'clustername', 'clustermembers'],
         oracletableData: [],
         oracleoptions: {
         templates: {
            },
          headings: {
                serverName: 'ServerName',
                type: 'Type',
                os: 'OS Type',
                dbNames: 'Database name',
                priDbName: 'Oracle DataGuard Primary Node Servicename',
                dbSize: 'Database Size in GB',
                dbChangeRate: 'Change Rate in % per day',
                dbLogSize: 'Archive Log Size per day in GB',
                clustername: 'Cluster name',
                clustermembers: 'Cluster Member Servers'           
            },
            text: {
                filter: 'Search  Virtual pools:',
                filterPlaceholder: 'Virtual pools...',
                limit: 'Entries per Page: '

            },
          filterable: false,
          perPage: 10,
          pagination: { chunk: 10, dropdown: false }
            // see the options API
        }
    }
  },
  mixins: [validationMixin],
  validations () {
    const valdef = {
    form_oracle: {
      serverName: {
        required
      },
      type: {
        required
      },
      os: {
        required
      },
      dbNames: {
        required
      },
      dbSize: {
        required,
        numeric,
        maxValue: maxValue(66560)
      },
      dbChangeRate: {
        required
      },
      dbLogSize: {
        required,
        numeric
      }
      }
    }
    if (this.form_oracle.type === 'Filesystem Cluster' || this.form_oracle.type === 'ASM Clustered' || this.form_oracle.type === 'RAC on ASM') {
    valdef.form_oracle.clustername = {required};
    valdef.form_oracle.clustermembers = {required};
    }
    if (this.$parent.actifio.purpose === 'Appendix J') {
      valdef.form_oracle.priDbName = {required};
    }
    return valdef
  },
  created () {
    const servDe = {
      serverDetails: this.oracletableData,
      isValid: true
    } 
    this.$emit('update', servDe)
    // this.getAppInfo();
  },
  methods: {
    onSubmit (e) {
      e.preventDefault()
      this.getappInfo()
    },
    getcluster (search, loading) {
      loading(true);
      this.search(loading, search, this);
    },
    search: _.debounce((loading, search, vm) => {
      vm.getServerDetailsByID(search).then(d => {
       vm.clusteroptions = [d.body.serverName]
       vm.showclustererror = false
        loading(false)
      })
      .catch(e => {
        vm.showclustererror = true
      })
    }),
    handleSubmit (e) {
      this.oracletableData.push(this.form_oracle)
      const servDe = {
      serverDetails: this.oracletableData,
      isValid: false
    }
    this.$emit('update', servDe)
      this.hidemodal_oracle()
    },
    onHidden_oracle () {
      // this.osversion = ['Window'Linux', 'AIX']
      this.form_oracle = {}
      this.popupTitle_oracle = 'New DB Server'
      this.showModal_oracle = false
    },
    hidemodal_oracle () {
    this.$refs.myModalRef_oracle.hide()
    },
    newserver_oracle () {
        this.showModal_oracle = true
        this.popupTitle_oracle = 'New DB Server' 
        this.$refs.myModalRef_oracle.show()
    },
getServerDetailsByID (sID) {
      const apiheaders = {
        headers: {
          'Content-Type': 'application/json'
  }
}    
  return this.$http.get('/api/servers?serverName=' + sID, apiheaders)
    },
    getserverInfo () {
      if (this.$parent.actifio.purpose === 'Appendix J') {
          this.isGuardVisible = true
      } else {
          this.isGuardVisible = false
      }
      const apiheaders = {
        headers: {
          'Content-Type': 'application/json'
  }
}     
      this.$http
        .get('/api/servers?serverName=' + this.actifio.serverId, apiheaders)
        .then((response) => {
          this.serverInfo = response;
          this.form_oracle.serverName = response.body.serverName;
          var ostype = '';
         // if (/Windows/i.test(response.body.os)) { ostype = 'Windows' }
          if (/Red Hat/i.test(response.body.os)) { ostype = 'Linux' }
          if (/AIX/i.test(response.body.os)) { ostype = 'AIX' }
          this.form_oracle.os = ostype;
          for (var i = 0; i < response.body.CSIID.length; i++) {
            if (response.body.CSIID[i] === this.$parent.actifio.CSIID) {
            this.newserver_oracle();
            this.isServerAssociated = false;
            break;
            } else {
              this.isServerAssociated = true;
            }
          }
          this.isserverNameValid = false;
        })
        .catch((response) => {
          this.isserverNameValid = true;
          console.log(response)
        })
    }
  }
}