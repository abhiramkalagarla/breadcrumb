/* global _ */
import { validationMixin } from 'vuelidate'
import { required, requiredUnless, requiredIf, numeric, maxValue } from 'vuelidate/lib/validators'
export default {
  name: 'mssqlTable',
  data () {
    return {
         showModal_mssql: false,
         popupTitle_mssql: 'New DB Server',
         theme: 'bootstrap4',
         actifio: {},
         form_mssql: {},
         isServerAssociated: false,
         isserverNameValid: false,
         hidefooter: true,
         template: 'default',
         dbChangeRate: [3, 5],
         dbNames: [],
         showclustererror: false,
         clusteroptions: [],
         type: ['Standalone', 'SQL Local instance in Availability group', 'Failover', 'SQL Availability group'],
         osversion: ['Windows'],
         mssqlcolumns: ['serverName', 'type', 'os', 'instanceNames', 'dbNames', 'dbSize', 'dbChangeRate', 'dbLogSize', 'clustermembers', 'clustername'],
         tableData: [],
         mssqloptions: {
            templates: {
          },
          headings: {
                serverName: 'ServerName',
                type: 'Type',
                os: 'OS Type',
                instanceNames: 'Instance name',
                dbNames: 'Database Name',                
                dbSize: 'Database Size in GB',
                dbChangeRate: 'Change Rate in % per day',
                dbLogSize: 'Archive Log Size per day in GB',
                clustermembers: 'Cluster Member Servers',
                clustername: 'Cluster name'
            },
          text: {
                filter: 'Search  Virtual pools:',
                filterPlaceholder: 'Virtual pools...',
                limit: 'Entries per Page: '

            },
          filterable: false,
          perPage: 10,
          pagination: { chunk: 10, dropdown: false }
            // see the options API
          }
    }
  },
  mixins: [validationMixin],
  validations () {
    const valdef = {
      form_mssql: {
      serverName: {
        required
      },
      type: {
        required
      },
      os: {
        required
      },
      dbNames: {
        required
      },
      dbSize: {
        required,
        numeric,
        maxValue: maxValue(66560)
      },
      dbChangeRate: {
        required
      },
      dbLogSize: {
        required,
        numeric
      }
    }
    }
    if (this.form_mssql.type === 'Failover' || this.form_mssql.type === 'SQL Availability group') {
    valdef.form_mssql.clustername = {required};
    valdef.form_mssql.clustermembers = {required};
    }
    if (this.form_mssql.os === 'Windows') {
      valdef.form_mssql.instanceNames = {required};
    }
    return valdef
  },
  created () {
    const servDe = {
      serverDetails: this.tableData,
      isValid: true
    } 
    this.$emit('update', servDe)
    // this.getAppInfo();
  },
  methods: {
    onSubmit (e) {
      e.preventDefault()
      this.getappInfo()
    },
    getcluster (search, loading) {
      loading(true);
      this.search(loading, search, this);
    },
    search: _.debounce((loading, search, vm) => {
      vm.getServerDetailsByID(search).then(d => {
       vm.clusteroptions = [d.body.serverName]
       vm.showclustererror = false
        loading(false)
      })
      .catch(e => {
        vm.showclustererror = true
      })
    }),
    handleSubmit () {
      this.tableData.push(this.form_mssql)
      const servDe = {
      serverDetails: this.tableData,
      isValid: false
    }
    this.$emit('update', servDe)
      this.hidemodal_mssql()
    },
    onHidden_mssql () {
      // this.osVersion = ['Windows', 'Linux', 'AIX']
      this.form_mssql = {}
      this.popupTitle_mssql = 'New DB Server'
      this.showModal_mssql = false
    },
    hidemodal_mssql () {
      this.$refs.myModalRef_mssql.hide()
    },
    newserver_mssql () {
        this.showModal_mssql = true
        this.popupTitle_mssql = 'New DB Server' 
        this.$refs.myModalRef_mssql.show()
    },
    getServerDetailsByID (sID) {
      const apiheaders = {
        headers: {
          'Content-Type': 'application/json'
  }
}    
  return this.$http.get('/api/servers?serverName=' + sID, apiheaders)
    },
    getserverInfo () {
      this.getServerDetailsByID(this.actifio.serverId).then(response => {
        this.serverInfo = response;
          this.form_mssql.serverName = response.body.serverName;
          var ostype = '';
          if (/Windows/i.test(response.body.os)) { ostype = 'Windows' }
          // if (/Red Hat/i.test(response.body.os)) { ostype = 'Linux' }
          // if (/AIX/i.test(response.body.os)) { ostype = 'AIX' }
          this.form_mssql.os = ostype;
          for (var i = 0; i < response.body.CSIID.length; i++) {
            if (response.body.CSIID[i] === this.$parent.actifio.CSIID) {
            this.newserver_mssql();
            this.isServerAssociated = false;
            break;
            } else {
              this.isServerAssociated = true;
            }
          }
          this.isserverNameValid = false;
        }).catch(e => {
          console.log(e)
          this.isserverNameValid = true;
        })
    }
  }
}