<template>
  <div class="mt-2">
  <p><b>Add Servers to be protected. Additional details required upon ServerName validation</b></p>
<b-row>
  <b-col md="4">
    <b-form-group id="Group1"
      description="The entered server will be treated as Primary Database server for Database protection service">
        <b-input-group>
              <b-form-input id="serverId"
                    type="text"
                    v-model="actifio.serverId"
                    aria-describedby="serverId"
                    placeholder="Enter Server Name" />
                    <b-input-group-append>
                    <button type="button" @click="getserverInfo()" class="btn btn-primary" >Add Server</button>
                    </b-input-group-append>
        </b-input-group> 
        <span class="invalid-feedback d-block" v-if="isServerAssociated">The entered server is either not in Aperture or doesnot belong to the CSI ID</span>
        <span class="invalid-feedback d-block" v-if="isserverNameValid">The Entered Server Name is invalid</span>
    </b-form-group>
  </b-col>
  </b-row>
    <v-client-table :data="tableData" :columns="mssqlcolumns" :options="mssqloptions"></v-client-table>

    <b-modal v-model="showModal_mssql" no-enforce-focus :hide-footer="hidefooter"  ref="myModalRef_mssql" :title="popupTitle_mssql"  @hidden="onHidden_mssql">
      <form>
           <b-form-group id="DataCenter"
                      label="Server Name"
                      class="required"
                      label-for="servernameInput">
          <b-form-input id="servernameInput"
                      type="text"
                      v-model="form_mssql.serverName"
                      :state="null"
                      aria-describedby="servernameInput"
                      placeholder="Server Name"/>
          <b-form-invalid-feedback id="servernameInput">
            This is a required field
          </b-form-invalid-feedback>
          </b-form-group>

          <b-form-group id="OfflinePools"
                        label="Type*:"
                        description="Select the Database Type"
                        :label-cols="2"
                        breakpoint="md"
                        label-for="type">
            <b-form-select id="type"
                        :options="type"
                        v-model="form_mssql.type"
                        aria-describedby="type"
                        placeholder="Select Server Typer"/>
            </b-form-group>

          <b-form-group id="DataCenter"
                      label="OS"
                      class="required"
                      label-for="osversionInput">
                      <b-form-select id="osversionInput"
                      :options="osversion"
                      v-model="form_mssql.os"
                      :state="null"
                      aria-describedby="osversionInput"
                      placeholder="OS Type" />
          <b-form-invalid-feedback id="osversionInput">
            This is a required field
          </b-form-invalid-feedback>
          </b-form-group>

          <b-form-group id="DataCenter"
          v-if="form_mssql.os === 'Windows'"
                      label="Instance Name"
                      description="Hint: Instancename/Hostname"
                      class="required"
                      label-for="instancenameInput">
                      <v-select taggable multiple v-model="form_mssql.instanceNames"></v-select>
          <b-form-invalid-feedback id="instancenameInput">
            This is a required field
          </b-form-invalid-feedback>
          </b-form-group>

          <b-form-group id="DataCenter"
                      label="Database Names"
                      class="required"
                      label-for="databasenameInput">
                      <v-select taggable multiple v-model="form_mssql.dbNames"></v-select>
                      <small 
                     class="form-text text-muted">Enter "All" or Individual DB Names</small>
          <b-form-invalid-feedback id="databasenameInput">
            This is a required field
          </b-form-invalid-feedback>
          </b-form-group>

          <b-form-group id="DataCenter"
                      label="DB Size in GB"
                      class="required"
                      label-for="databasesizeInput">
          <b-form-input id="databasesizeInput"
                      type="number"
                      v-model.number="form_mssql.dbSize"
                      :state="null"
                      aria-describedby="databasesizeInput"
                      placeholder="Database Size in GB" />
          <b-form-invalid-feedback id="databasesizeInput">
            This is a required field
          </b-form-invalid-feedback>
          <div class="text-danger" v-if="!$v.form_mssql.dbSize.maxValue">DB Size should be max {{$v.form_mssql.dbSize.$params.maxValue.max}} in GB </div>
          </b-form-group>

         <b-form-group id="DataCenter"
                      label="Change Rate in % per day"
                      description="Hint:Average change rate of 5% "
                      class="required"
                      label-for="changerateInput">
          <b-form-select id="changerateInput"
                      :options="dbChangeRate"
                      v-model="form_mssql.dbChangeRate"
                      aria-describedby="changerateInput"
                      placeholder="Change Rate in % per day" />
          <b-form-invalid-feedback id="changeRateInput">
            This is a required field
          </b-form-invalid-feedback>
          </b-form-group>

            <b-form-group id="DataCenter"
                      label="Archive Log Size per day in GB"
                      class="required"
                      label-for="dblogsizeInput">
          <b-form-input id="dblogsizeInput"
                      type="number"
                      v-model.number="form_mssql.dbLogSize"
                      :state="null"
                      aria-describedby="dblogsizeInput"
                      placeholder="Archive Log Size per day in GB" />
          <b-form-invalid-feedback id="dblogsizeInput">
            This is a required field
          </b-form-invalid-feedback>
          </b-form-group>

          <b-form-group id="DataCenter"
                      label="Cluster name/Listener name"
                      class="required"
                      v-if="form_mssql.type === 'Failover' || form_mssql.type === 'SQL Availability group'"
                      label-for="clusternameInput">
          <b-form-input id="clusternameInput"
                      type="text"
                      v-model="form_mssql.clustername"
                      :state="null"
                      aria-describedby="clusternameInput"
                      placeholder="Cluster name" />
          <b-form-invalid-feedback id="clusternameInput">
            This is a required field
          </b-form-invalid-feedback>
          </b-form-group>

          <b-form-group id="DataCenter"
                      label="Cluster Member Servers"
                      class="required"
                      v-if="form_mssql.type === 'Failover' || form_mssql.type === 'SQL Availability group'"
                      label-for="clustermemberserversInput">
                      <v-select  multiple :options="clusteroptions" :filterable="false"
                      @search="getcluster"
                       v-model="form_mssql.clustermembers"></v-select>
                       <small 
                     class="form-text text-muted">Enter Cluster Member Servernames</small>
                       <span class="text-danger" v-if="showclustererror">Servername not found in Aperture</span>
          <b-form-invalid-feedback id="clustermemberserversInput">
            This is a required field
          </b-form-invalid-feedback>
          </b-form-group>
            
          <b-button type="button" @click="handleSubmit()" :disabled="$v.form_mssql.$invalid" variant="primary" >
              Submit
          </b-button>
          <b-button type="button" @click="hidemodal_mssql()" variant="default">
            Cancel
          </b-button>
      </form>
    </b-modal>
  </div>
</template>

<script src="./mssqlTable.js">

</script>
