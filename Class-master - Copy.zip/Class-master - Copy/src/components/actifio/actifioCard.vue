<template>

  <div >
  <b-row>
  <b-col class="mt-10">
    <b-card-group deck>

        <b-card title="Enable Database Backup">
            <p class="card-text">
                This service enables automated backup of Databases
            </p>
            <div slot="footer">
                <b-button to="/actifio/enableDatabaseBackup"
                      variant="primary">Order</b-button>
            </div>
        </b-card>

        <b-card title="Manage Database Backup">
            <p class="card-text">
                
            </p>
            <div slot="footer">
                <b-button to="/actifio/manageDatabaseBackup"
                      variant="primary">Order</b-button>
            </div>
        </b-card>

        <b-card title="Database Backup Dashboard">
            <p class="card-text">
                
            </p>
            <div slot="footer">
                <b-button to="/actifio/databaseBackupDashboard" disabled
                      variant="primary">Order</b-button>
            </div>
        </b-card>

    </b-card-group>
  </b-col>
  </b-row>
  </div>

</template>

<script>
export default {
  name: 'actifioCard',
  data () {
    return {
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.mt-10{
  margin-top:10px;
}
</style>
