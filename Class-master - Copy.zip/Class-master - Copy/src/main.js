import store from './store'
// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import 'es6-promise/auto'
/* Vue */
import Vue from 'vue'
import router from './router'
import VueResource from 'vue-resource'
import BootstrapVue from 'bootstrap-vue'
import Breabcrumbs from 'vue-2-breadcrumbs'
import App from './components/App.vue'
import vSelect from 'vue-select'

/* Auth plugin */
import Auth from './auth'
import {ServerTable, ClientTable, Event} from 'vue-tables-2';
import Toasted from 'vue-toasted';
import VueCtkDateTimePicker from 'vue-ctk-date-time-picker';
import 'vue-ctk-date-time-picker/dist/vue-ctk-date-time-picker.min.css';

Vue.component('vue-ctk-date-time-picker', VueCtkDateTimePicker);
Vue.use(Breabcrumbs)
Vue.use(VueResource)
Vue.component('v-select', vSelect)
/* App sass */
require('../node_modules/bootstrap/dist/css/bootstrap.min.css')
require('../node_modules/font-awesome/css/font-awesome.min.css')
require('./assets/style/app.scss')

Vue.use(Toasted)
 
Vue.use(BootstrapVue)
Vue.use(ClientTable, null, false, 'bootstrap4');
// Vue.use(Breabcrumbs)
Vue.config.productionTip = false

Vue.use(Auth)

/* eslint-disable no-new */
new Vue({
  el: '#app',
  data () {
    return {
      appVersion: '1.0',
      showloader: false
    }
  },
  /* http: {
    emulateJSON: true,
    emulateHTTP: true
  }, */
  // Attach the Vue instance to the window,
  // so it's available globally.
  created: function () {
    window.Vue = this
  },
  router: router,
  store: store,
  render: h => h(App)
})
